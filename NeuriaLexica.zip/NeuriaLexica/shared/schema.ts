import { pgTable, serial, text, timestamp, integer, real, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Waveforms table - stores user-created waveforms
export const waveforms = pgTable("waveforms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // sine, square, triangle, sawtooth
  frequency: real("frequency").notNull(),
  amplitude: real("amplitude").notNull(),
  phase: real("phase").notNull(),
  code: text("code"), // Custom waveform code
  basePattern: text("base_pattern"), // focused, creative, relaxed, energized
  varianceLayer: text("variance_layer"), // stable, moderate, dynamic, chaotic
  temporalResolution: text("temporal_resolution"), // realtime, hourly, daily, weekly
  data: json("data"), // Serialized waveform data points
  createdAt: timestamp("created_at").defaultNow()
});

export const insertWaveformSchema = createInsertSchema(waveforms).omit({ 
  id: true,
  createdAt: true 
});
export type InsertWaveform = z.infer<typeof insertWaveformSchema>;
export type SelectWaveform = typeof waveforms.$inferSelect;

// Chat messages table - stores AI chat history
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  role: text("role").notNull(), // user or assistant
  content: text("content").notNull(),
  planningContext: text("planning_context"),
  timestamp: timestamp("timestamp").defaultNow()
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true
});
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type SelectChatMessage = typeof chatMessages.$inferSelect;

// Side comments table - stores meta-comments on messages
export const sideComments = pgTable("side_comments", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").references(() => chatMessages.id),
  content: text("content").notNull(),
  tag: text("tag").notNull(), // meta, note, insight, etc
  createdAt: timestamp("created_at").defaultNow()
});

export const insertSideCommentSchema = createInsertSchema(sideComments).omit({
  id: true,
  createdAt: true
});
export type InsertSideComment = z.infer<typeof insertSideCommentSchema>;
export type SelectSideComment = typeof sideComments.$inferSelect;

// Planning items table - stores planning objectives
export const planningItems = pgTable("planning_items", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  status: text("status").notNull(), // pending, active, completed
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at")
});

export const insertPlanningItemSchema = createInsertSchema(planningItems).omit({
  id: true,
  createdAt: true,
  completedAt: true
});
export type InsertPlanningItem = z.infer<typeof insertPlanningItemSchema>;
export type SelectPlanningItem = typeof planningItems.$inferSelect;

// Goals table - stores user goals and targets
export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  primaryGoal: text("primary_goal").notNull(),
  targetVariance: integer("target_variance").notNull(),
  timeframe: text("timeframe").notNull(), // 1-month, 3-months, 6-months, 1-year
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertGoalSchema = createInsertSchema(goals).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
export type InsertGoal = z.infer<typeof insertGoalSchema>;
export type SelectGoal = typeof goals.$inferSelect;

// Metrics table - stores performance metrics over time
export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  metric: text("metric").notNull(), // stability, consistency, recovery, adaptation
  value: real("value").notNull(),
  change: real("change"), // Percentage change from previous
  status: text("status").notNull(), // improving, excellent, declining
  timestamp: timestamp("timestamp").defaultNow()
});

export const insertMetricSchema = createInsertSchema(metrics).omit({
  id: true,
  timestamp: true
});
export type InsertMetric = z.infer<typeof insertMetricSchema>;
export type SelectMetric = typeof metrics.$inferSelect;

// Settings table - stores user preferences
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  aiModel: text("ai_model").notNull(), // basic, advanced, deep
  samplingRate: text("sampling_rate").notNull(), // real-time, 5-min, hourly, daily
  autoSync: boolean("auto_sync").notNull().default(true),
  privateMode: boolean("private_mode").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true
});
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type SelectSettings = typeof settings.$inferSelect;

// Extensions table - stores installed extensions
export const extensions = pgTable("extensions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // analysis, transform, visualization
  config: json("config"), // Extension configuration
  installed: boolean("installed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertExtensionSchema = createInsertSchema(extensions).omit({
  id: true,
  createdAt: true
});
export type InsertExtension = z.infer<typeof insertExtensionSchema>;
export type SelectExtension = typeof extensions.$inferSelect;