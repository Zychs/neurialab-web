# Neuria Lexica

## Overview

Neuria Lexica is a multimodal mental health analytics platform that enables users to create, analyze, and derive insights from mental health artifacts across video, audio, and text modalities. The application extracts "waveforms of the mind" by analyzing patterns in user-submitted content to provide mental health analytics and personal insights.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript
- Vite for build tooling and development server
- TanStack Query for server state management
- Wouter for client-side routing

**Design System:**
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS with custom design tokens following hybrid Apple HIG / Carbon Design principles
- Therapeutic minimalism aesthetic prioritizing cognitive load reduction
- Inter font for UI/data, JetBrains Mono for technical metadata

**Component Architecture:**
The application uses a component-based architecture with:
- Atomic design pattern for UI components (buttons, inputs, cards)
- Feature-specific composite components (waveform charts, artifact cards, upload zones)
- Panel-based navigation system with three primary action areas: Build, Think, Change
- Sheet/drawer patterns for contextual interactions

**Key UI Patterns:**
- Minimal landing page with three primary actions
- Dashboard with waveform visualization and artifact library
- Artifact viewer with split-view media player and analysis panel
- Form-based entry creation with multimodal file upload

### Backend Architecture

**Technology Stack:**
- Node.js with Express server
- TypeScript throughout
- ESM module system

**Database Layer:**
- Drizzle ORM for type-safe database operations
- PostgreSQL via Neon serverless database
- WebSocket connection support for real-time operations
- Schema-first approach with Zod validation

**Storage Pattern:**
- Abstraction layer (IStorage interface) allowing for multiple implementations
- Current in-memory storage (MemStorage) for development
- Designed for easy migration to database-backed storage

**API Design:**
- RESTful API endpoints under `/api` prefix
- Request logging middleware with response capture
- JSON body parsing with raw body preservation for webhook verification
- Session management ready (connect-pg-simple dependency present)

### Data Models

**Core Entities:**
- Users (authentication/authorization)
- Artifacts (multimodal entries - video, audio, text)
- Analytics data (variance scores, temporal patterns)

**Artifact Properties:**
- Title, modality type, timestamp
- Variance score (mental state indicator)
- File metadata (thumbnails, excerpts, duration)
- Analysis results (to be implemented)

### External Dependencies

**AI/ML Integration:**
- Google Generative AI SDK (@google/genai) for artifact analysis
- Prepared for multimodal content processing (video, audio, text transcription)

**Database:**
- Neon Serverless PostgreSQL
- Connection pooling via @neondatabase/serverless
- WebSocket support for low-latency operations

**UI Component Libraries:**
- Radix UI primitives for accessible component foundation
- Recharts for data visualization (waveform charts, analytics)
- Lucide React for iconography
- date-fns for temporal data handling

**Form Management:**
- React Hook Form with Zod resolver for type-safe validation
- Drizzle-Zod integration for database schema validation

**Development Tools:**
- Replit-specific plugins for development experience
- Vite runtime error overlay
- Cartographer for code mapping (Replit environment)

### Authentication & Session Management

**Prepared Infrastructure:**
- PostgreSQL session store (connect-pg-simple)
- User schema with username/password fields
- Session cookie configuration ready for implementation

**Current State:**
- Basic user CRUD operations defined in storage layer
- Authentication endpoints not yet implemented
- Routes placeholder exists for future API endpoints

### File Upload & Processing

**Upload Capabilities:**
- Drag-and-drop upload zone component
- Multi-file support with type validation
- Accepts video/*, audio/*, .txt, .md files
- Client-side file preview and management

**Processing Pipeline (Planned):**
- Server-side file storage (not yet implemented)
- Multimodal analysis via Google Generative AI
- Variance score calculation from content analysis
- Metadata extraction (duration, file size, thumbnails)

### Analytics & Visualization

**Waveform Analysis:**
- Time-series variance data tracking mental state patterns
- Artifact count correlation with variance intensity
- Interactive chart with drill-down capability
- Multi-week trend visualization

**Dashboard Metrics:**
- Total artifact count
- Average variance score with trend indicators
- Analysis streak tracking
- Modality distribution analysis

**Chart Implementation:**
- Recharts library for responsive visualizations
- Custom theming aligned with design system
- Accessible data presentation with proper labels and legends