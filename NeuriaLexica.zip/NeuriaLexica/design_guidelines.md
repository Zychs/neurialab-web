# Neuria Lexica Design Guidelines

## Design Approach
**System**: Hybrid approach combining Apple HIG's therapeutic minimalism with Carbon Design's data visualization patterns. This balances the calm, focused mental health context with robust analytics capabilities.

**Core Principles**:
- Therapeutic clarity: Remove cognitive load through clean hierarchy
- Data transparency: Make complex analytics accessible and understandable
- Trust through restraint: Professional medical-grade interface standards

---

## Typography System

**Font Families**: 
- Primary: Inter (UI, data, labels)
- Monospace: JetBrains Mono (timestamps, technical metadata)

**Hierarchy**:
- Page titles: text-4xl font-semibold (artifact viewer, dashboard)
- Section headers: text-2xl font-medium
- Component titles: text-lg font-medium
- Body text: text-base font-normal
- Data labels: text-sm font-medium
- Metadata/timestamps: text-xs font-mono
- Buttons: text-sm font-medium

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 3, 4, 6, 8, 12, 16
- Component padding: p-6 or p-8
- Section spacing: space-y-8 or space-y-12
- Card gaps: gap-6
- Tight groupings: gap-3 or gap-4
- Page margins: px-8 lg:px-16

**Grid Structure**:
- Dashboard: 12-column grid with 2:1 ratio (waveform visualization spans 8 cols, sidebar 4 cols)
- Artifact library: Masonry grid with 3-4 columns on desktop, 2 on tablet, 1 on mobile
- Artifact viewer: Split view 60/40 (media player 60%, analysis panel 40%)

**Container Widths**:
- Main content: max-w-7xl mx-auto
- Artifact viewer: Full width with inner constraints
- Forms/inputs: max-w-2xl

---

## Component Library

### Navigation
**Primary Navigation**: Fixed sidebar (w-64) with:
- App logo/branding at top
- Main sections: Dashboard, Artifacts, New Entry, Analytics, Settings
- User profile at bottom with logout
- Active state: border-l-4 treatment on selected item

**Secondary Navigation**: Breadcrumb trail for artifact deep-dive (Dashboard > Artifacts > [Artifact Name])

### Artifact Cards
**Structure**:
- Thumbnail preview (aspect-ratio-video for video, waveform preview for audio, text excerpt for text)
- Metadata row: modality icon, timestamp, variance score badge
- Title truncated to 2 lines
- Hover state: subtle lift with shadow elevation
- Dimensions: Flexible height, min-h-48

### Waveform Visualization
**Primary Dashboard Component**:
- Full-width timeline chart with x-axis (dates) and y-axis (variance intensity 0-100)
- Interactive scrubbing: click timeline to jump to specific date/artifact
- Overlay indicators: dots marking artifact entries on timeline
- Legend panel: variance types color-coded (intentionally omitting colors per guidelines)
- Responsive: Collapses to vertical scroll on mobile

### Artifact Viewer
**Layout**:
- Left pane (60%): Media player with native controls
  - Video: aspect-ratio-video container with playback controls
  - Audio: Waveform visualization with scrubber
  - Text: Readable text-lg in max-w-prose container
- Right pane (40%): Analysis panel with tabs
  - Overview: Key metrics in stat cards (variance score, duration, modality)
  - Variance Data: Line chart of frame-by-frame or segment analysis
  - Metadata: Timestamp, file info, tags

**Media Controls**: Custom player controls with:
- Play/pause, skip forward/back (10s increments)
- Timeline scrubber with timestamp labels
- Playback speed selector (0.5x, 1x, 1.5x, 2x)

### Data Displays

**Stat Cards**: Grid layout for metrics
- Large number: text-3xl font-bold
- Label below: text-sm opacity-70
- Optional trend indicator (↑↓) in corner
- Padding: p-6, rounded-xl

**Timeline Component**: 
- Vertical timeline for entry chronology
- Dot markers with connecting line
- Entry cards branch right from timeline
- Alternating alignment on desktop (zigzag pattern)

**Tables**: For detailed analytics
- Sticky header row
- Zebra striping for row differentiation
- Compact row height: py-3 px-4
- Sortable columns with indicator icons
- Right-align numerical data

### Forms & Inputs

**New Entry Form**:
- Upload dropzone: Dashed border, min-h-64, drag-and-drop enabled
- File type icons displayed after upload with remove button
- Text input: Resizable textarea, min-h-32
- Tags input: Pill-style tag creation (type + enter)
- Submit button: Full-width on mobile, max-w-xs on desktop

**Input Styling**:
- Text inputs: Rounded borders, p-3, focus ring treatment
- Labels: text-sm font-medium, mb-2
- Helper text: text-xs opacity-70
- Error states: border treatment + text-red message below

### Modals & Overlays

**Confirmation Dialogs**: Centered modal, max-w-md
- Title: text-xl font-semibold
- Description: text-base, space-y-4
- Actions: Right-aligned button group with gap-3

**Analysis Drawer**: Slide-in from right (w-96)
- Close button top-right
- Scrollable content area
- Fixed action footer if needed

---

## Accessibility

- All interactive elements: min-h-11 touch target
- Form inputs: Persistent visible labels (never placeholder-only)
- Focus indicators: 2px ring offset on all focusable elements
- Skip navigation link for keyboard users
- ARIA labels on icon-only buttons
- Semantic HTML throughout (nav, main, article, aside)

---

## Images

**Hero Section**: Not applicable - dashboard app leads with functional interface

**Artifact Thumbnails**: 
- Video artifacts: Auto-generated thumbnail from first frame, aspect-ratio-video
- Whiteboard/artistic content: Full preview thumbnail showing visual variance
- Facial analysis: Anonymized/abstracted representation (not actual face capture)
- Beat Saber replays: Game screenshot or motion trail visualization

**Empty States**:
- New user dashboard: Illustration showing multimodal upload concept (video, audio, text icons)
- Empty artifact library: Welcoming illustration prompting first entry creation
- Placement: Centered in container with call-to-action below

**Profile/Avatar**: User avatar in navigation sidebar (circular, w-10 h-10)

---

## Animations

**Minimal, Purposeful Motion**:
- Page transitions: 150ms fade-in for new content
- Waveform drawing: 800ms animation on initial load (draws left-to-right)
- Artifact card hover: 200ms subtle lift
- Modal entry/exit: 250ms slide + fade
- NO scroll-triggered animations (maintain therapeutic calm)