import { useCallback, useState } from "react";
import { Upload, FileVideo, FileAudio, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export interface UploadedFile {
  id: string;
  name: string;
  type: "video" | "audio" | "text";
  size: number;
  file: File;
}

export interface UploadZoneProps {
  onFilesChange?: (files: UploadedFile[]) => void;
  acceptedTypes?: string[];
}

const fileTypeIcons = {
  video: FileVideo,
  audio: FileAudio,
  text: FileText,
};

export function UploadZone({ onFilesChange, acceptedTypes = ["video/*", "audio/*", ".txt", ".md"] }: UploadZoneProps) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const getFileType = (file: File): "video" | "audio" | "text" => {
    if (file.type.startsWith("video/")) return "video";
    if (file.type.startsWith("audio/")) return "audio";
    return "text";
  };

  const handleFiles = useCallback((fileList: FileList | null) => {
    if (!fileList) return;

    const newFiles: UploadedFile[] = Array.from(fileList).map((file) => ({
      id: `${Date.now()}-${Math.random()}`,
      name: file.name,
      type: getFileType(file),
      size: file.size,
      file,
    }));

    const updatedFiles = [...files, ...newFiles];
    setFiles(updatedFiles);
    onFilesChange?.(updatedFiles);
  }, [files, onFilesChange]);

  const removeFile = (id: string) => {
    const updatedFiles = files.filter((f) => f.id !== id);
    setFiles(updatedFiles);
    onFilesChange?.(updatedFiles);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  return (
    <div className="space-y-4">
      <Card
        className={`min-h-64 border-2 border-dashed transition-colors ${
          isDragging ? "border-primary bg-primary/5" : "border-border"
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
      >
        <label className="flex flex-col items-center justify-center h-64 cursor-pointer p-6">
          <Upload className="w-12 h-12 text-muted-foreground mb-4" />
          <p className="text-base font-medium mb-2">Drop files here or click to upload</p>
          <p className="text-sm text-muted-foreground mb-4">
            Supports video, audio, and text files
          </p>
          <Button type="button" variant="secondary" size="sm" data-testid="button-browse-files">
            Browse Files
          </Button>
          <input
            type="file"
            className="hidden"
            multiple
            accept={acceptedTypes.join(",")}
            onChange={(e) => handleFiles(e.target.files)}
            data-testid="input-file-upload"
          />
        </label>
      </Card>

      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((file) => {
            const Icon = fileTypeIcons[file.type];
            return (
              <div
                key={file.id}
                className="flex items-center gap-3 p-3 rounded-md bg-muted"
                data-testid={`file-item-${file.id}`}
              >
                <Icon className="w-5 h-5 text-muted-foreground" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeFile(file.id)}
                  data-testid={`button-remove-${file.id}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
