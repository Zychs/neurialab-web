import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Hammer, Brain, Sliders } from "lucide-react";
import { BuildPanel } from "./panels/build-panel";
import { ThinkPanel } from "./panels/think-panel";
import { ChangePanel } from "./panels/change-panel";

type PanelType = "build" | "think" | "change" | null;

export function MinimalLanding() {
  const [activePanel, setActivePanel] = useState<PanelType>(null);

  const closePanel = () => setActivePanel(null);

  return (
    <div className="h-screen w-full flex items-center justify-center bg-background">
      <div className="text-center space-y-12 px-8 max-w-2xl">
        {/* Subtle branding */}
        <div className="space-y-2">
          <h1 className="text-2xl font-light tracking-wider text-foreground/80">
            Neuria Lexica
          </h1>
          <p className="text-xs font-mono text-muted-foreground">
            waveform of the mind
          </p>
        </div>

        {/* Three primary actions */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <Button
            variant="outline"
            size="lg"
            className="w-40 h-40 flex flex-col gap-3 hover-elevate active-elevate-2 border-2"
            onClick={() => setActivePanel("build")}
            data-testid="button-build"
          >
            <Hammer className="w-8 h-8" />
            <span className="text-lg font-light">Build</span>
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="w-40 h-40 flex flex-col gap-3 hover-elevate active-elevate-2 border-2"
            onClick={() => setActivePanel("think")}
            data-testid="button-think"
          >
            <Brain className="w-8 h-8" />
            <span className="text-lg font-light">Think</span>
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="w-40 h-40 flex flex-col gap-3 hover-elevate active-elevate-2 border-2"
            onClick={() => setActivePanel("change")}
            data-testid="button-change"
          >
            <Sliders className="w-8 h-8" />
            <span className="text-lg font-light">Change</span>
          </Button>
        </div>
      </div>

      {/* Build Panel */}
      <Sheet open={activePanel === "build"} onOpenChange={(open) => !open && closePanel()}>
        <SheetContent side="bottom" className="h-[80vh] overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-2xl font-light">Build</SheetTitle>
          </SheetHeader>
          <BuildPanel onClose={closePanel} />
        </SheetContent>
      </Sheet>

      {/* Think Panel */}
      <Sheet open={activePanel === "think"} onOpenChange={(open) => !open && closePanel()}>
        <SheetContent side="bottom" className="h-[80vh] overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-2xl font-light">Think</SheetTitle>
          </SheetHeader>
          <ThinkPanel onClose={closePanel} />
        </SheetContent>
      </Sheet>

      {/* Change Panel */}
      <Sheet open={activePanel === "change"} onOpenChange={(open) => !open && closePanel()}>
        <SheetContent side="bottom" className="h-[80vh] overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-2xl font-light">Change</SheetTitle>
          </SheetHeader>
          <ChangePanel onClose={closePanel} />
        </SheetContent>
      </Sheet>
    </div>
  );
}