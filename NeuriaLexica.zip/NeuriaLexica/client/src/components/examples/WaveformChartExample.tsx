import { WaveformChart } from "../waveform-chart";

export default function WaveformChartExample() {
  const mockData = [
    { date: "Jan 1", variance: 45, artifactCount: 1 },
    { date: "Jan 3", variance: 52, artifactCount: 2 },
    { date: "Jan 5", variance: 48, artifactCount: 1 },
    { date: "Jan 7", variance: 65, artifactCount: 3 },
    { date: "Jan 9", variance: 58, artifactCount: 2 },
    { date: "Jan 11", variance: 72, artifactCount: 1 },
    { date: "Jan 13", variance: 68, artifactCount: 2 },
    { date: "Jan 15", variance: 55, artifactCount: 1 },
  ];

  return (
    <div className="p-8">
      <WaveformChart
        data={mockData}
        onPointClick={(point) => console.log("Point clicked:", point)}
      />
    </div>
  );
}
