import { ArtifactCard } from "../artifact-card";

export default function ArtifactCardExample() {
  return (
    <div className="p-8 max-w-sm">
      <ArtifactCard
        id="1"
        title="Morning Reflection - Creative Expression"
        modality="video"
        timestamp={new Date("2024-01-15")}
        varianceScore={72}
        thumbnailUrl="https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=400&h=225&fit=crop"
        onClick={() => console.log("Artifact clicked")}
      />
    </div>
  );
}
