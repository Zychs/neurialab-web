import { UploadZone } from "../upload-zone";

export default function UploadZoneExample() {
  return (
    <div className="p-8 max-w-2xl">
      <UploadZone
        onFilesChange={(files) => console.log("Files changed:", files)}
      />
    </div>
  );
}
