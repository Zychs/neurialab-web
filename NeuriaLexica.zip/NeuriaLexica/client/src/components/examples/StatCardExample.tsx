import { StatCard } from "../stat-card";
import { FileText, TrendingUp } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl">
      <StatCard
        label="Total Artifacts"
        value={42}
        icon={FileText}
        trend="up"
        trendValue="+8 this week"
      />
      <StatCard
        label="Avg Variance"
        value={64.2}
        icon={TrendingUp}
        trend="up"
        trendValue="+5.2%"
      />
      <StatCard
        label="Analysis Streak"
        value="7 days"
      />
    </div>
  );
}
