import { MinimalLanding } from "../minimal-landing";

export default function MinimalLandingExample() {
  return <MinimalLanding />;
}