import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Send, MessageSquare, StickyNote, Target, Bot, User, Hash, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ThinkPanelProps {
  onClose: () => void;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  planningContext?: string;
}

interface SideComment {
  id: string;
  messageId: string;
  content: string;
  tag: string;
}

interface PlanningItem {
  id: string;
  content: string;
  status: "active" | "completed" | "pending";
}

export function ThinkPanel({ onClose }: ThinkPanelProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("chat");
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Chat state
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm here to help you think through your mental patterns and analyze your waveforms. What would you like to explore today?",
      timestamp: new Date(),
    }
  ]);
  
  // Side comments state
  const [sideComments, setSideComments] = useState<SideComment[]>([
    {
      id: "1",
      messageId: "1",
      content: "Initial greeting established connection",
      tag: "meta"
    }
  ]);
  
  // Planning state
  const [planningItems, setPlanningItems] = useState<PlanningItem[]>([
    {
      id: "1",
      content: "Establish baseline mental state patterns",
      status: "active"
    },
    {
      id: "2",
      content: "Identify variance triggers",
      status: "pending"
    }
  ]);
  
  const [newPlanItem, setNewPlanItem] = useState("");
  const [newSideComment, setNewSideComment] = useState("");
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      planningContext: planningItems.find(p => p.status === "active")?.content
    };
    
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setIsTyping(true);
    
    try {
      // Call the AI chat endpoint
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
          planningContext: planningItems.find(p => p.status === "active")?.content
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to get AI response");
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.content,
        timestamp: new Date(),
        planningContext: planningItems.find(p => p.status === "active")?.content
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Connection Error",
        description: "Unable to connect to AI. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleAddPlanItem = () => {
    if (!newPlanItem.trim()) return;
    
    const item: PlanningItem = {
      id: Date.now().toString(),
      content: newPlanItem,
      status: "pending"
    };
    
    setPlanningItems(prev => [...prev, item]);
    setNewPlanItem("");
    
    toast({
      title: "Planning item added",
      description: "New objective added to planning layer",
    });
  };

  const handleAddSideComment = () => {
    if (!newSideComment.trim() || !selectedMessage) return;
    
    const comment: SideComment = {
      id: Date.now().toString(),
      messageId: selectedMessage,
      content: newSideComment,
      tag: "note"
    };
    
    setSideComments(prev => [...prev, comment]);
    setNewSideComment("");
    setSelectedMessage(null);
    
    toast({
      title: "Side comment added",
      description: "Comment attached to message",
    });
  };

  const togglePlanStatus = (id: string) => {
    setPlanningItems(prev => prev.map(item => {
      if (item.id === id) {
        const newStatus = item.status === "pending" ? "active" : 
                         item.status === "active" ? "completed" : "pending";
        return { ...item, status: newStatus };
      }
      return item;
    }));
  };

  return (
    <div className="mt-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          data-testid="button-back-think"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Bot className="w-4 h-4" />
          <span className="font-mono">AI Analysis Active</span>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
          <TabsTrigger value="chat" data-testid="tab-chat">
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat
          </TabsTrigger>
          <TabsTrigger value="planning" data-testid="tab-planning">
            <Target className="w-4 h-4 mr-2" />
            Planning
          </TabsTrigger>
          <TabsTrigger value="comments" data-testid="tab-comments">
            <StickyNote className="w-4 h-4 mr-2" />
            Comments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="flex-1 flex flex-col space-y-4">
          <ScrollArea className="flex-1 pr-4" ref={scrollRef}>
            <div className="space-y-4 pb-4">
              {messages.map((message) => {
                const comments = sideComments.filter(c => c.messageId === message.id);
                return (
                  <div key={message.id} className="space-y-2">
                    <div className={`flex gap-3 ${message.role === "user" ? "justify-end" : ""}`}>
                      {message.role === "assistant" && (
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}
                      <div className={`max-w-[70%] space-y-2 ${message.role === "user" ? "items-end" : ""}`}>
                        {message.planningContext && (
                          <Badge variant="outline" className="text-xs">
                            <Hash className="w-3 h-3 mr-1" />
                            {message.planningContext}
                          </Badge>
                        )}
                        <Card className={message.role === "user" ? "bg-primary/5" : ""}>
                          <CardContent className="p-4">
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs text-muted-foreground mt-2">
                              {message.timestamp.toLocaleTimeString()}
                            </p>
                          </CardContent>
                        </Card>
                        {comments.length > 0 && (
                          <div className="pl-4 space-y-1">
                            {comments.map(comment => (
                              <div key={comment.id} className="text-xs text-muted-foreground italic">
                                [{comment.tag}] {comment.content}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      {message.role === "user" && (
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              {isTyping && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <Bot className="w-4 h-4" />
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
                        <span className="w-2 h-2 bg-primary rounded-full animate-pulse delay-100"></span>
                        <span className="w-2 h-2 bg-primary rounded-full animate-pulse delay-200"></span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder="Ask about patterns, analyze waveforms..."
              className="flex-1"
              data-testid="input-chat-message"
            />
            <Button onClick={handleSendMessage} data-testid="button-send-message">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="planning" className="flex-1 flex flex-col space-y-4">
          <Card className="flex-1">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newPlanItem}
                    onChange={(e) => setNewPlanItem(e.target.value)}
                    placeholder="Add planning objective..."
                    className="flex-1"
                    data-testid="input-plan-item"
                  />
                  <Button onClick={handleAddPlanItem} size="sm" data-testid="button-add-plan">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  {planningItems.map((item) => (
                    <div
                      key={item.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        item.status === "active" ? "border-primary bg-primary/5" :
                        item.status === "completed" ? "opacity-60" : ""
                      }`}
                      onClick={() => togglePlanStatus(item.id)}
                      data-testid={`planning-item-${item.id}`}
                    >
                      <div className="flex items-start justify-between">
                        <p className={`text-sm ${item.status === "completed" ? "line-through" : ""}`}>
                          {item.content}
                        </p>
                        <Badge
                          variant={
                            item.status === "active" ? "default" :
                            item.status === "completed" ? "secondary" : "outline"
                          }
                          className="text-xs"
                        >
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>

                {planningItems.length === 0 && (
                  <p className="text-center text-muted-foreground text-sm py-8">
                    No planning objectives yet. Add one to guide the conversation.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comments" className="flex-1 flex flex-col space-y-4">
          <Card className="flex-1">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-sm">Add side comment to message</Label>
                  <Select value={selectedMessage || ""} onValueChange={setSelectedMessage}>
                    <SelectTrigger data-testid="select-message-comment">
                      <SelectValue placeholder="Select a message" />
                    </SelectTrigger>
                    <SelectContent>
                      {messages.map((msg, idx) => (
                        <SelectItem key={msg.id} value={msg.id}>
                          Message {idx + 1}: {msg.content.substring(0, 30)}...
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {selectedMessage && (
                    <div className="flex gap-2">
                      <Input
                        value={newSideComment}
                        onChange={(e) => setNewSideComment(e.target.value)}
                        placeholder="Add comment..."
                        className="flex-1"
                        data-testid="input-side-comment"
                      />
                      <Button onClick={handleAddSideComment} size="sm" data-testid="button-add-comment">
                        Add
                      </Button>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <h3 className="text-sm font-medium">All Comments</h3>
                  {sideComments.map((comment) => {
                    const message = messages.find(m => m.id === comment.messageId);
                    return (
                      <div key={comment.id} className="p-3 rounded-lg border">
                        <Badge variant="outline" className="text-xs mb-2">
                          {comment.tag}
                        </Badge>
                        <p className="text-sm">{comment.content}</p>
                        {message && (
                          <p className="text-xs text-muted-foreground mt-2">
                            On: "{message.content.substring(0, 50)}..."
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>

                {sideComments.length === 0 && (
                  <p className="text-center text-muted-foreground text-sm py-8">
                    No side comments yet. Comments help track meta-thoughts without disrupting flow.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Add missing imports at the top
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";