import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Play, Pause, Save, Download, Plus, Code, Waves, Layers } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid } from "recharts";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { SelectWaveform, SelectExtension } from "@shared/schema";

interface BuildPanelProps {
  onClose: () => void;
}


export function BuildPanel({ onClose }: BuildPanelProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("waveform");
  const [isPlaying, setIsPlaying] = useState(false);
  const [waveformName, setWaveformName] = useState("Untitled Waveform");
  
  // Waveform parameters
  const [frequency, setFrequency] = useState([5]);
  const [amplitude, setAmplitude] = useState([50]);
  const [phase, setPhase] = useState([0]);
  const [waveType, setWaveType] = useState("sine");
  const [pattern, setPattern] = useState("focused");
  const [variance, setVariance] = useState("moderate");
  const [currentWaveformData, setCurrentWaveformData] = useState<any[]>([]);
  
  // Code editor state
  const [code, setCode] = useState(`// Waveform Constructor
// Define your mental state waveform

function generateWaveform(t) {
  // Base frequency: thought patterns
  const base = Math.sin(2 * Math.PI * 0.1 * t);
  
  // Variance layer: emotional fluctuation
  const variance = 0.3 * Math.sin(2 * Math.PI * 0.5 * t);
  
  // Noise: environmental factors
  const noise = 0.1 * (Math.random() - 0.5);
  
  return base + variance + noise;
}

// Export for analysis
export default generateWaveform;`);

  // Fetch waveforms
  const { data: waveforms } = useQuery<SelectWaveform[]>({
    queryKey: ["/api/waveforms"]
  });

  // Fetch extensions
  const { data: extensions } = useQuery<SelectExtension[]>({
    queryKey: ["/api/extensions"]
  });

  // Generate waveform mutation
  const generateWaveform = useMutation({
    mutationFn: async () => {
      return apiRequest("/api/waveforms/generate", "POST", {
        type: waveType,
        frequency: frequency[0],
        amplitude: amplitude[0],
        phase: phase[0],
        pattern,
        variance
      });
    },
    onSuccess: (data: any) => {
      setCurrentWaveformData(data.points || []);
    }
  });

  // Save waveform mutation
  const saveWaveform = useMutation({
    mutationFn: async () => {
      return apiRequest("/api/waveforms", "POST", {
        name: waveformName,
        type: waveType,
        pattern,
        variance,
        frequency: frequency[0],
        amplitude: amplitude[0],
        phase: phase[0],
        data: currentWaveformData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/waveforms"] });
      toast({
        title: "Waveform saved",
        description: "Your construction has been stored for analysis",
      });
    }
  });

  // Analyze waveform mutation  
  const analyzeWaveform = useMutation({
    mutationFn: async (extensionName: string) => {
      if (!waveforms || waveforms.length === 0) {
        throw new Error("No waveform to analyze");
      }
      const latestWaveform = waveforms[waveforms.length - 1];
      return apiRequest(`/api/waveforms/${latestWaveform.id}/analyze`, "POST", {
        extensionName
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Analysis complete",
        description: `Extension ${data.extensionName} executed successfully`,
      });
    }
  });

  // Generate initial waveform on mount and when parameters change
  useEffect(() => {
    generateWaveform.mutate();
  }, [frequency[0], amplitude[0], phase[0], waveType, pattern, variance]);

  const handleSave = () => {
    saveWaveform.mutate();
  };

  const handleRunCode = () => {
    console.log("Running code:", code);
    toast({
      title: "Code executed",
      description: "Waveform updated with new parameters",
    });
  };

  return (
    <div className="mt-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          data-testid="button-back-build"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsPlaying(!isPlaying)}
            data-testid="button-play-waveform"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSave}
            data-testid="button-save-waveform"
          >
            <Save className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            data-testid="button-export-waveform"
          >
            <Download className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
          <TabsTrigger value="waveform" data-testid="tab-waveform">
            <Waves className="w-4 h-4 mr-2" />
            Waveform
          </TabsTrigger>
          <TabsTrigger value="code" data-testid="tab-code">
            <Code className="w-4 h-4 mr-2" />
            Code
          </TabsTrigger>
          <TabsTrigger value="extensions" data-testid="tab-extensions">
            <Layers className="w-4 h-4 mr-2" />
            Extensions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="waveform" className="flex-1 space-y-6">
          <Card>
            <CardContent className="p-6">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={currentWaveformData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="x" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <Line
                    type="monotone"
                    dataKey="y"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Wave Parameters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Wave Type</Label>
                  <Select value={waveType} onValueChange={setWaveType}>
                    <SelectTrigger data-testid="select-wave-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sine">Sine</SelectItem>
                      <SelectItem value="square">Square</SelectItem>
                      <SelectItem value="sawtooth">Sawtooth</SelectItem>
                      <SelectItem value="triangle">Triangle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Frequency</Label>
                    <span className="text-sm text-muted-foreground">{frequency[0]} Hz</span>
                  </div>
                  <Slider
                    value={frequency}
                    onValueChange={setFrequency}
                    min={1}
                    max={20}
                    step={1}
                    data-testid="slider-frequency"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Amplitude</Label>
                    <span className="text-sm text-muted-foreground">{amplitude[0]}%</span>
                  </div>
                  <Slider
                    value={amplitude}
                    onValueChange={setAmplitude}
                    min={0}
                    max={100}
                    step={5}
                    data-testid="slider-amplitude"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Phase Shift</Label>
                    <span className="text-sm text-muted-foreground">{phase[0]}°</span>
                  </div>
                  <Slider
                    value={phase}
                    onValueChange={setPhase}
                    min={0}
                    max={360}
                    step={15}
                    data-testid="slider-phase"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Mental State Mapping</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Base Pattern</Label>
                  <Select defaultValue="focused">
                    <SelectTrigger data-testid="select-base-pattern">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="focused">Focused</SelectItem>
                      <SelectItem value="creative">Creative</SelectItem>
                      <SelectItem value="relaxed">Relaxed</SelectItem>
                      <SelectItem value="energized">Energized</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Variance Layer</Label>
                  <Select defaultValue="moderate">
                    <SelectTrigger data-testid="select-variance-layer">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stable">Stable</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="dynamic">Dynamic</SelectItem>
                      <SelectItem value="chaotic">Chaotic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Temporal Resolution</Label>
                  <Select defaultValue="hourly">
                    <SelectTrigger data-testid="select-temporal">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="realtime">Real-time</SelectItem>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="code" className="flex-1 flex flex-col space-y-4">
          <Card className="flex-1">
            <CardContent className="p-6 h-full">
              <div className="h-full flex flex-col">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm font-mono text-muted-foreground">waveform.js</span>
                  <Button size="sm" onClick={handleRunCode} data-testid="button-run-code">
                    <Play className="w-3 h-3 mr-2" />
                    Run
                  </Button>
                </div>
                <textarea
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="flex-1 w-full p-4 font-mono text-sm bg-card border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  spellCheck={false}
                  data-testid="textarea-code-editor"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="extensions" className="flex-1 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Installed Extensions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded-lg border">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">Fourier Transform</p>
                      <p className="text-xs text-muted-foreground">Frequency domain analysis</p>
                    </div>
                    <Button variant="ghost" size="sm">Configure</Button>
                  </div>
                </div>
                <div className="p-3 rounded-lg border">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">Pattern Recognition</p>
                      <p className="text-xs text-muted-foreground">ML-based pattern detection</p>
                    </div>
                    <Button variant="ghost" size="sm">Configure</Button>
                  </div>
                </div>
                <div className="p-3 rounded-lg border">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">Biometric Sync</p>
                      <p className="text-xs text-muted-foreground">Heart rate variability mapping</p>
                    </div>
                    <Button variant="ghost" size="sm">Configure</Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Available Extensions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded-lg border opacity-70">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">Chaos Theory</p>
                      <p className="text-xs text-muted-foreground">Nonlinear dynamics analysis</p>
                    </div>
                    <Button variant="outline" size="sm" data-testid="button-install-chaos">
                      <Plus className="w-3 h-3 mr-1" />
                      Install
                    </Button>
                  </div>
                </div>
                <div className="p-3 rounded-lg border opacity-70">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">Quantum States</p>
                      <p className="text-xs text-muted-foreground">Superposition modeling</p>
                    </div>
                    <Button variant="outline" size="sm" data-testid="button-install-quantum">
                      <Plus className="w-3 h-3 mr-1" />
                      Install
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}