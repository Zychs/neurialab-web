import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Settings, Target, TrendingUp, Activity, CheckCircle2, AlertCircle } from "lucide-react";
import { Line, LineChart, Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { useToast } from "@/hooks/use-toast";

interface ChangePanelProps {
  onClose: () => void;
}

//todo: remove mock functionality
const mockGoalProgress = [
  { week: "W1", variance: 72, target: 60 },
  { week: "W2", variance: 68, target: 60 },
  { week: "W3", variance: 65, target: 60 },
  { week: "W4", variance: 61, target: 60 },
  { week: "W5", variance: 58, target: 60 },
];

const mockMetrics = [
  { metric: "Stability", value: 78, change: "+12%", status: "improving" },
  { metric: "Consistency", value: 65, change: "+5%", status: "improving" },
  { metric: "Recovery", value: 82, change: "+18%", status: "excellent" },
  { metric: "Adaptation", value: 54, change: "-3%", status: "declining" },
];

export function ChangePanel({ onClose }: ChangePanelProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("goals");
  
  // Settings state
  const [aiModel, setAiModel] = useState("advanced");
  const [autoSync, setAutoSync] = useState(true);
  const [privateMode, setPrivateMode] = useState(false);
  const [samplingRate, setSamplingRate] = useState("real-time");
  
  // Goals state
  const [primaryGoal, setPrimaryGoal] = useState("Achieve mental stability");
  const [targetVariance, setTargetVariance] = useState([60]);
  const [timeframe, setTimeframe] = useState("3-months");

  const handleSaveSettings = () => {
    toast({
      title: "Settings updated",
      description: "Your preferences have been saved",
    });
  };

  const handleUpdateGoals = () => {
    toast({
      title: "Goals updated",
      description: "Your targets have been recalibrated",
    });
  };

  return (
    <div className="mt-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          data-testid="button-back-change"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
          <TabsTrigger value="goals" data-testid="tab-goals">
            <Target className="w-4 h-4 mr-2" />
            Goals
          </TabsTrigger>
          <TabsTrigger value="metrics" data-testid="tab-metrics">
            <TrendingUp className="w-4 h-4 mr-2" />
            Metrics
          </TabsTrigger>
          <TabsTrigger value="settings" data-testid="tab-settings">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="goals" className="flex-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Primary Objective</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="primary-goal">Current Goal</Label>
                <Input
                  id="primary-goal"
                  value={primaryGoal}
                  onChange={(e) => setPrimaryGoal(e.target.value)}
                  data-testid="input-primary-objective"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label>Target Variance</Label>
                  <span className="text-sm text-muted-foreground">{targetVariance[0]}</span>
                </div>
                <Slider
                  value={targetVariance}
                  onValueChange={setTargetVariance}
                  min={30}
                  max={90}
                  step={5}
                  data-testid="slider-target-variance"
                />
              </div>

              <div className="space-y-2">
                <Label>Timeframe</Label>
                <Select value={timeframe} onValueChange={setTimeframe}>
                  <SelectTrigger data-testid="select-timeframe">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-month">1 Month</SelectItem>
                    <SelectItem value="3-months">3 Months</SelectItem>
                    <SelectItem value="6-months">6 Months</SelectItem>
                    <SelectItem value="1-year">1 Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleUpdateGoals} className="w-full" data-testid="button-update-goals">
                Update Goals
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Progress Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={mockGoalProgress}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="week" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--popover-border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="variance"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    name="Actual"
                  />
                  <Line
                    type="monotone"
                    dataKey="target"
                    stroke="hsl(var(--chart-3))"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Target"
                  />
                </LineChart>
              </ResponsiveContainer>

              <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/20">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Goal Achievement</span>
                  <span className="text-lg font-bold">85%</span>
                </div>
                <Progress value={85} className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metrics" className="flex-1 space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            {mockMetrics.map((metric) => (
              <Card key={metric.metric}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{metric.metric}</p>
                      <p className="text-2xl font-bold mt-1">{metric.value}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {metric.status === "excellent" ? (
                          <CheckCircle2 className="w-4 h-4 text-chart-3" />
                        ) : metric.status === "improving" ? (
                          <TrendingUp className="w-4 h-4 text-chart-1" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-destructive" />
                        )}
                        <span className={`text-sm font-medium ${
                          metric.status === "declining" ? "text-destructive" : 
                          metric.status === "excellent" ? "text-chart-3" : "text-chart-1"
                        }`}>
                          {metric.change}
                        </span>
                      </div>
                    </div>
                    <Activity className="w-5 h-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={mockMetrics}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="metric" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--popover-border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="flex-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Analysis Model</Label>
                <Select value={aiModel} onValueChange={setAiModel}>
                  <SelectTrigger data-testid="select-ai-model">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="basic">Basic (Fast)</SelectItem>
                    <SelectItem value="advanced">Advanced (Balanced)</SelectItem>
                    <SelectItem value="deep">Deep Analysis (Thorough)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Data Sampling Rate</Label>
                <Select value={samplingRate} onValueChange={setSamplingRate}>
                  <SelectTrigger data-testid="select-sampling-rate">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="real-time">Real-time</SelectItem>
                    <SelectItem value="5-min">Every 5 minutes</SelectItem>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Privacy & Sync</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="auto-sync">Auto-sync Data</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically sync waveforms to cloud
                  </p>
                </div>
                <Switch
                  id="auto-sync"
                  checked={autoSync}
                  onCheckedChange={setAutoSync}
                  data-testid="switch-auto-sync"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="private-mode">Private Mode</Label>
                  <p className="text-xs text-muted-foreground">
                    Keep all data local only
                  </p>
                </div>
                <Switch
                  id="private-mode"
                  checked={privateMode}
                  onCheckedChange={setPrivateMode}
                  data-testid="switch-private-mode"
                />
              </div>

              <Button onClick={handleSaveSettings} className="w-full" data-testid="button-save-settings">
                Save Settings
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full" data-testid="button-export-data">
                Export Waveform Data
              </Button>
              <Button variant="outline" className="w-full" data-testid="button-backup">
                Create Backup
              </Button>
              <Button variant="destructive" className="w-full" data-testid="button-reset">
                Reset All Data
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Add missing import at the top
import { Slider } from "@/components/ui/slider";