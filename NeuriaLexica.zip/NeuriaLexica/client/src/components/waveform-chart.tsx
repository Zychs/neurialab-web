import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, Legend } from "recharts";

export interface WaveformDataPoint {
  date: string;
  variance: number;
  artifactCount: number;
}

export interface WaveformChartProps {
  data: WaveformDataPoint[];
  onPointClick?: (dataPoint: WaveformDataPoint) => void;
}

export function WaveformChart({ data, onPointClick }: WaveformChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Mental State Waveform</CardTitle>
        <p className="text-sm text-muted-foreground">
          Variance patterns derived from multimodal artifact analysis
        </p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={data}
            onClick={(e) => {
              if (e?.activePayload?.[0]?.payload && onPointClick) {
                onPointClick(e.activePayload[0].payload);
              }
            }}
            className="cursor-pointer"
          >
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="date"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <YAxis
              label={{ value: "Variance Intensity", angle: -90, position: "insideLeft" }}
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--popover-border))",
                borderRadius: "var(--radius)",
              }}
              labelStyle={{ color: "hsl(var(--popover-foreground))" }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="variance"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--chart-1))", r: 4 }}
              activeDot={{ r: 6 }}
              name="Variance Score"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
