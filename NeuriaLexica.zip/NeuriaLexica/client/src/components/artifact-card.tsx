import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileVideo, FileAudio, FileText, Calendar } from "lucide-react";
import { format } from "date-fns";

export type ModalityType = "video" | "audio" | "text";

export interface ArtifactCardProps {
  id: string;
  title: string;
  modality: ModalityType;
  timestamp: Date;
  varianceScore: number;
  thumbnailUrl?: string;
  excerpt?: string;
  onClick?: () => void;
}

const modalityConfig = {
  video: {
    icon: FileVideo,
    label: "Video",
    color: "bg-chart-1/10 text-chart-1",
  },
  audio: {
    icon: FileAudio,
    label: "Audio",
    color: "bg-chart-2/10 text-chart-2",
  },
  text: {
    icon: FileText,
    label: "Text",
    color: "bg-chart-3/10 text-chart-3",
  },
};

export function ArtifactCard({
  id,
  title,
  modality,
  timestamp,
  varianceScore,
  thumbnailUrl,
  excerpt,
  onClick,
}: ArtifactCardProps) {
  const config = modalityConfig[modality];
  const ModalityIcon = config.icon;

  return (
    <Card
      className="hover-elevate active-elevate-2 cursor-pointer transition-all min-h-48 flex flex-col"
      onClick={onClick}
      data-testid={`card-artifact-${id}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-medium text-lg line-clamp-2 flex-1">{title}</h3>
          <Badge variant="secondary" className="text-xs">
            {varianceScore}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1">
        {modality === "video" && thumbnailUrl && (
          <div className="aspect-video bg-muted rounded-md mb-3 overflow-hidden">
            <img src={thumbnailUrl} alt={title} className="w-full h-full object-cover" />
          </div>
        )}
        {modality === "text" && excerpt && (
          <p className="text-sm text-muted-foreground line-clamp-3">{excerpt}</p>
        )}
        {modality === "audio" && (
          <div className="aspect-video bg-muted rounded-md mb-3 flex items-center justify-center">
            <FileAudio className="w-12 h-12 text-muted-foreground" />
          </div>
        )}
      </CardContent>

      <CardFooter className="pt-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded ${config.color}`}>
            <ModalityIcon className="w-3 h-3" />
          </div>
          <span className="text-xs font-medium">{config.label}</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
          <Calendar className="w-3 h-3" />
          {format(timestamp, "MMM d, yyyy")}
        </div>
      </CardFooter>
    </Card>
  );
}
