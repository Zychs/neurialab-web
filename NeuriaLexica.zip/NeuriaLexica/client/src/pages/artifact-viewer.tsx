import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileVideo, Calendar, ArrowLeft, Play, Pause } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { useState } from "react";
import { format } from "date-fns";

//todo: remove mock functionality
const mockVarianceData = [
  { time: "0:00", variance: 45 },
  { time: "0:10", variance: 52 },
  { time: "0:20", variance: 48 },
  { time: "0:30", variance: 65 },
  { time: "0:40", variance: 58 },
  { time: "0:50", variance: 72 },
  { time: "1:00", variance: 68 },
];

export default function ArtifactViewer() {
  const [, params] = useRoute("/artifact/:id");
  const [, setLocation] = useLocation();
  const [isPlaying, setIsPlaying] = useState(false);

  //todo: remove mock functionality - fetch real artifact data
  const artifact = {
    id: params?.id || "1",
    title: "Morning Creative Session",
    modality: "video",
    timestamp: new Date("2024-01-19"),
    varianceScore: 70,
    duration: "1:23",
    fileSize: "24.5 MB",
    thumbnailUrl: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=800&h=450&fit=crop",
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation("/artifacts")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-4xl font-semibold mb-2">{artifact.title}</h1>
          <div className="flex items-center gap-3 text-sm text-muted-foreground font-mono">
            <span>{format(artifact.timestamp, "MMM d, yyyy 'at' h:mm a")}</span>
            <span>•</span>
            <span>{artifact.duration}</span>
          </div>
        </div>
        <Badge variant="secondary" className="text-base px-4 py-2">
          Variance: {artifact.varianceScore}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="overflow-hidden">
            <div className="aspect-video bg-muted relative group">
              <img
                src={artifact.thumbnailUrl}
                alt={artifact.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/30 transition-colors">
                <Button
                  size="icon"
                  className="w-16 h-16 rounded-full"
                  onClick={() => setIsPlaying(!isPlaying)}
                  data-testid="button-play-pause"
                >
                  {isPlaying ? (
                    <Pause className="w-8 h-8" />
                  ) : (
                    <Play className="w-8 h-8" />
                  )}
                </Button>
              </div>
            </div>
            <div className="p-4 bg-card border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileVideo className="w-4 h-4" />
                  <span>{artifact.modality}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>{artifact.fileSize}</span>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Frame-by-Frame Variance</CardTitle>
              <p className="text-sm text-muted-foreground">
                Variance intensity across the artifact timeline
              </p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={mockVarianceData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="time"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--popover-border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="variance"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--chart-1))", r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Tabs defaultValue="overview">
            <TabsList className="w-full">
              <TabsTrigger value="overview" className="flex-1" data-testid="tab-overview">
                Overview
              </TabsTrigger>
              <TabsTrigger value="metadata" className="flex-1" data-testid="tab-metadata">
                Metadata
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Variance Score</p>
                    <p className="text-2xl font-bold">{artifact.varianceScore}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Duration</p>
                    <p className="text-lg font-medium">{artifact.duration}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Modality</p>
                    <Badge>{artifact.modality}</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Analysis Insights</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-medium mb-1">Peak Variance</p>
                    <p className="text-muted-foreground">
                      Highest intensity at 0:50 (72 points)
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-medium mb-1">Stability</p>
                    <p className="text-muted-foreground">
                      Moderate variance fluctuation throughout
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metadata" className="space-y-4 mt-6">
              <Card>
                <CardContent className="p-6 space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span className="font-mono">
                      {format(artifact.timestamp, "MMM d, yyyy")}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">File Size</span>
                    <span className="font-mono">{artifact.fileSize}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Resolution</span>
                    <span className="font-mono">1920x1080</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Format</span>
                    <span className="font-mono">MP4</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frame Rate</span>
                    <span className="font-mono">30 fps</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="space-y-3">
            <Button variant="outline" className="w-full" data-testid="button-download">
              Download Artifact
            </Button>
            <Button variant="outline" className="w-full" data-testid="button-share">
              Share Analysis
            </Button>
            <Button variant="destructive" className="w-full" data-testid="button-delete">
              Delete Artifact
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
