import { ArtifactCard, type ArtifactCardProps, type ModalityType } from "@/components/artifact-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

//todo: remove mock functionality
const mockArtifacts: Omit<ArtifactCardProps, "onClick">[] = [
  {
    id: "1",
    title: "Morning Creative Session",
    modality: "video",
    timestamp: new Date("2024-01-19"),
    varianceScore: 70,
    thumbnailUrl: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=400&h=225&fit=crop",
  },
  {
    id: "2",
    title: "Evening Reflection",
    modality: "text",
    timestamp: new Date("2024-01-18"),
    varianceScore: 62,
    excerpt: "Today was challenging but rewarding. I noticed patterns in my focus levels...",
  },
  {
    id: "3",
    title: "Meditation Audio Log",
    modality: "audio",
    timestamp: new Date("2024-01-17"),
    varianceScore: 55,
  },
  {
    id: "4",
    title: "Beat Saber Performance Analysis",
    modality: "video",
    timestamp: new Date("2024-01-16"),
    varianceScore: 78,
    thumbnailUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=225&fit=crop",
  },
  {
    id: "5",
    title: "Whiteboard Brainstorm",
    modality: "video",
    timestamp: new Date("2024-01-15"),
    varianceScore: 65,
    thumbnailUrl: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=225&fit=crop",
  },
  {
    id: "6",
    title: "Voice Journal Entry",
    modality: "audio",
    timestamp: new Date("2024-01-14"),
    varianceScore: 58,
  },
  {
    id: "7",
    title: "Daily Thoughts",
    modality: "text",
    timestamp: new Date("2024-01-13"),
    varianceScore: 52,
    excerpt: "Feeling more centered today. The morning routine is starting to show results...",
  },
  {
    id: "8",
    title: "Facial Expression Analysis",
    modality: "video",
    timestamp: new Date("2024-01-12"),
    varianceScore: 68,
    thumbnailUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=225&fit=crop",
  },
];

export default function Artifacts() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [modalityFilter, setModalityFilter] = useState<ModalityType | "all">("all");

  const filteredArtifacts = mockArtifacts.filter((artifact) => {
    const matchesSearch = artifact.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesModality = modalityFilter === "all" || artifact.modality === modalityFilter;
    return matchesSearch && matchesModality;
  });

  const handleArtifactClick = (artifactId: string) => {
    setLocation(`/artifact/${artifactId}`);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Artifacts</h1>
        <p className="text-muted-foreground">
          Browse and analyze your multimodal journal entries
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search artifacts..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search-artifacts"
          />
        </div>

        <Tabs value={modalityFilter} onValueChange={(v) => setModalityFilter(v as ModalityType | "all")}>
          <TabsList>
            <TabsTrigger value="all" data-testid="filter-all">All</TabsTrigger>
            <TabsTrigger value="video" data-testid="filter-video">Video</TabsTrigger>
            <TabsTrigger value="audio" data-testid="filter-audio">Audio</TabsTrigger>
            <TabsTrigger value="text" data-testid="filter-text">Text</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {filteredArtifacts.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-lg text-muted-foreground">No artifacts found</p>
          <p className="text-sm text-muted-foreground mt-2">
            Try adjusting your search or filters
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArtifacts.map((artifact) => (
            <ArtifactCard
              key={artifact.id}
              {...artifact}
              onClick={() => handleArtifactClick(artifact.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
