import { WaveformChart, type WaveformDataPoint } from "@/components/waveform-chart";
import { ArtifactCard, type ArtifactCardProps } from "@/components/artifact-card";
import { StatCard } from "@/components/stat-card";
import { FileText, BarChart3, Calendar } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

//todo: remove mock functionality
const mockWaveformData: WaveformDataPoint[] = [
  { date: "Jan 1", variance: 45, artifactCount: 1 },
  { date: "Jan 3", variance: 52, artifactCount: 2 },
  { date: "Jan 5", variance: 48, artifactCount: 1 },
  { date: "Jan 7", variance: 65, artifactCount: 3 },
  { date: "Jan 9", variance: 58, artifactCount: 2 },
  { date: "Jan 11", variance: 72, artifactCount: 1 },
  { date: "Jan 13", variance: 68, artifactCount: 2 },
  { date: "Jan 15", variance: 55, artifactCount: 1 },
  { date: "Jan 17", variance: 62, artifactCount: 2 },
  { date: "Jan 19", variance: 70, artifactCount: 1 },
];

//todo: remove mock functionality
const mockArtifacts: Omit<ArtifactCardProps, "onClick">[] = [
  {
    id: "1",
    title: "Morning Creative Session",
    modality: "video",
    timestamp: new Date("2024-01-19"),
    varianceScore: 70,
    thumbnailUrl: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=400&h=225&fit=crop",
  },
  {
    id: "2",
    title: "Evening Reflection",
    modality: "text",
    timestamp: new Date("2024-01-18"),
    varianceScore: 62,
    excerpt: "Today was challenging but rewarding. I noticed patterns in my focus levels that align with my energy cycles...",
  },
  {
    id: "3",
    title: "Meditation Audio Log",
    modality: "audio",
    timestamp: new Date("2024-01-17"),
    varianceScore: 55,
  },
];

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const handleWaveformClick = (dataPoint: WaveformDataPoint) => {
    setSelectedDate(dataPoint.date);
    console.log("Waveform point clicked:", dataPoint);
  };

  const handleArtifactClick = (artifactId: string) => {
    setLocation(`/artifact/${artifactId}`);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Overview of your mental state analytics and recent artifacts
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          label="Total Artifacts"
          value={42}
          icon={FileText}
          trend="up"
          trendValue="+8 this week"
        />
        <StatCard
          label="Avg Variance Score"
          value={64.2}
          icon={BarChart3}
          trend="up"
          trendValue="+5.2%"
        />
        <StatCard
          label="Analysis Streak"
          value="7 days"
          icon={Calendar}
        />
      </div>

      <WaveformChart data={mockWaveformData} onPointClick={handleWaveformClick} />

      <div>
        <h2 className="text-2xl font-medium mb-6">Recent Artifacts</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockArtifacts.map((artifact) => (
            <ArtifactCard
              key={artifact.id}
              {...artifact}
              onClick={() => handleArtifactClick(artifact.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
