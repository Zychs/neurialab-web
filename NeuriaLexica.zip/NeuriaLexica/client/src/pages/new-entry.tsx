import { useState } from "react";
import { UploadZone, type UploadedFile } from "@/components/upload-zone";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function NewEntry() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please provide a title for your entry",
        variant: "destructive",
      });
      return;
    }

    if (files.length === 0 && !notes.trim()) {
      toast({
        title: "Content required",
        description: "Please upload files or add text notes",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    //todo: remove mock functionality - replace with actual API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    console.log("Submitting entry:", { title, notes, files });
    
    toast({
      title: "Entry created",
      description: "Your artifact is being analyzed...",
    });
    
    setIsSubmitting(false);
    setLocation("/artifacts");
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-4xl font-semibold mb-2">New Entry</h1>
        <p className="text-muted-foreground">
          Create a new multimodal artifact for analysis
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Entry Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                type="text"
                placeholder="e.g., Morning Creative Session"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                data-testid="input-title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Add any additional context or observations..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="min-h-32 resize-none"
                data-testid="input-notes"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upload Files</CardTitle>
            <p className="text-sm text-muted-foreground">
              Upload video, audio, or text files for multimodal analysis
            </p>
          </CardHeader>
          <CardContent>
            <UploadZone onFilesChange={setFiles} />
          </CardContent>
        </Card>

        <div className="flex gap-3 justify-end">
          <Button
            type="button"
            variant="outline"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            data-testid="button-submit"
          >
            {isSubmitting ? "Creating..." : "Create Entry"}
          </Button>
        </div>
      </form>
    </div>
  );
}
