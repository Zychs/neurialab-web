import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { WaveformChart } from "@/components/waveform-chart";
import { StatCard } from "@/components/stat-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, Activity, Brain, Calendar } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

//todo: remove mock functionality
const mockWaveformData = [
  { date: "Week 1", variance: 45, artifactCount: 3 },
  { date: "Week 2", variance: 52, artifactCount: 5 },
  { date: "Week 3", variance: 48, artifactCount: 4 },
  { date: "Week 4", variance: 65, artifactCount: 7 },
  { date: "Week 5", variance: 58, artifactCount: 6 },
  { date: "Week 6", variance: 72, artifactCount: 8 },
  { date: "Week 7", variance: 68, artifactCount: 7 },
  { date: "Week 8", variance: 55, artifactCount: 5 },
];

//todo: remove mock functionality
const modalityDistribution = [
  { modality: "Video", count: 18, percentage: 43 },
  { modality: "Audio", count: 12, percentage: 29 },
  { modality: "Text", count: 12, percentage: 28 },
];

export default function Analytics() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Analytics</h1>
        <p className="text-muted-foreground">
          Deep insights into your mental state patterns and trends
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          label="Total Entries"
          value={42}
          icon={Calendar}
        />
        <StatCard
          label="Avg Variance"
          value={64.2}
          icon={Activity}
          trend="up"
          trendValue="+5.2%"
        />
        <StatCard
          label="Peak Variance"
          value={92}
          icon={TrendingUp}
        />
        <StatCard
          label="Pattern Stability"
          value="Good"
          icon={Brain}
        />
      </div>

      <Tabs defaultValue="timeline" className="space-y-6">
        <TabsList>
          <TabsTrigger value="timeline" data-testid="tab-timeline">Timeline</TabsTrigger>
          <TabsTrigger value="distribution" data-testid="tab-distribution">Distribution</TabsTrigger>
          <TabsTrigger value="patterns" data-testid="tab-patterns">Patterns</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-6">
          <WaveformChart data={mockWaveformData} />
          
          <Card>
            <CardHeader>
              <CardTitle>Variance Trends</CardTitle>
              <p className="text-sm text-muted-foreground">
                Weekly variance intensity patterns over time
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                  <div>
                    <p className="text-sm font-medium">Highest Variance Period</p>
                    <p className="text-xs text-muted-foreground">Week 6</p>
                  </div>
                  <p className="text-2xl font-bold">72</p>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                  <div>
                    <p className="text-sm font-medium">Most Stable Period</p>
                    <p className="text-xs text-muted-foreground">Week 1</p>
                  </div>
                  <p className="text-2xl font-bold">45</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Modality Distribution</CardTitle>
              <p className="text-sm text-muted-foreground">
                Breakdown of artifact types in your collection
              </p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={modalityDistribution}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="modality"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--popover-border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {modalityDistribution.map((item) => (
              <Card key={item.modality}>
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground mb-2">{item.modality}</p>
                  <p className="text-3xl font-bold mb-1">{item.count}</p>
                  <p className="text-sm text-muted-foreground">{item.percentage}% of total</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Pattern Recognition</CardTitle>
              <p className="text-sm text-muted-foreground">
                AI-identified patterns in your mental state waveforms
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium">Weekly Cycle Pattern</p>
                  <span className="text-xs font-mono bg-chart-1/10 text-chart-1 px-2 py-1 rounded">
                    High Confidence
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Variance tends to increase mid-week (Wed-Thu) and stabilize on weekends
                </p>
              </div>

              <div className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium">Modality Correlation</p>
                  <span className="text-xs font-mono bg-chart-3/10 text-chart-3 px-2 py-1 rounded">
                    Medium Confidence
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Video artifacts correlate with higher variance scores compared to text entries
                </p>
              </div>

              <div className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium">Recovery Trend</p>
                  <span className="text-xs font-mono bg-chart-4/10 text-chart-4 px-2 py-1 rounded">
                    High Confidence
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Long-term variance is stabilizing, showing improved mental state regulation
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
