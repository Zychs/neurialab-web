import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateChatResponse, analyzeWaveform, generatePlanningSuggestions } from "./ai";
import { generateWaveform, applyMentalStatePattern } from "./waveform";
import { extensionManager } from "./extensions";

export async function registerRoutes(app: Express): Promise<Server> {
  // AI Chat endpoint for Think panel with persistence
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, planningContext, saveToHistory = true } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required" });
      }

      // Save user message to history
      if (saveToHistory && messages.length > 0) {
        const lastMessage = messages[messages.length - 1];
        if (lastMessage.role === "user") {
          await storage.insertChatMessage({
            role: lastMessage.role,
            content: lastMessage.content,
            planningContext
          });
        }
      }

      // Generate AI response
      const response = await generateChatResponse(messages, planningContext);

      // Save AI response to history
      if (saveToHistory) {
        await storage.insertChatMessage({
          role: "assistant",
          content: response,
          planningContext
        });
      }

      res.json({ content: response });
    } catch (error) {
      console.error("Chat endpoint error:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // Get chat history
  app.get("/api/chat/history", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const messages = await storage.getChatMessages(limit);
      res.json(messages);
    } catch (error) {
      console.error("Chat history error:", error);
      res.status(500).json({ error: "Failed to get chat history" });
    }
  });

  // Clear chat history
  app.delete("/api/chat/history", async (req, res) => {
    try {
      await storage.clearChatHistory();
      res.json({ success: true });
    } catch (error) {
      console.error("Clear chat history error:", error);
      res.status(500).json({ error: "Failed to clear chat history" });
    }
  });

  // Waveform endpoints
  app.post("/api/waveforms/generate", async (req, res) => {
    try {
      const { type, frequency, amplitude, phase, pattern, variance } = req.body;
      const basePoints = generateWaveform(type, frequency, amplitude, phase);
      const points = applyMentalStatePattern(basePoints, pattern, variance);
      res.json({ points });
    } catch (error) {
      console.error("Error generating waveform:", error);
      res.status(500).json({ error: "Failed to generate waveform" });
    }
  });

  app.post("/api/waveforms", async (req, res) => {
    try {
      const waveform = await storage.insertWaveform(req.body);
      res.json(waveform);
    } catch (error) {
      console.error("Create waveform error:", error);
      res.status(500).json({ error: "Failed to create waveform" });
    }
  });

  app.get("/api/waveforms", async (req, res) => {
    try {
      const waveforms = await storage.getWaveforms();
      res.json(waveforms);
    } catch (error) {
      console.error("Get waveforms error:", error);
      res.status(500).json({ error: "Failed to get waveforms" });
    }
  });

  app.get("/api/waveforms/:id", async (req, res) => {
    try {
      const waveform = await storage.getWaveformById(parseInt(req.params.id));
      if (!waveform) {
        return res.status(404).json({ error: "Waveform not found" });
      }
      res.json(waveform);
    } catch (error) {
      console.error("Get waveform error:", error);
      res.status(500).json({ error: "Failed to get waveform" });
    }
  });

  app.put("/api/waveforms/:id", async (req, res) => {
    try {
      const waveform = await storage.updateWaveform(parseInt(req.params.id), req.body);
      if (!waveform) {
        return res.status(404).json({ error: "Waveform not found" });
      }
      res.json(waveform);
    } catch (error) {
      console.error("Update waveform error:", error);
      res.status(500).json({ error: "Failed to update waveform" });
    }
  });

  app.delete("/api/waveforms/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteWaveform(parseInt(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: "Waveform not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete waveform error:", error);
      res.status(500).json({ error: "Failed to delete waveform" });
    }
  });

  // Analyze waveform with extension
  app.post("/api/waveforms/:id/analyze", async (req, res) => {
    try {
      const { extensionName } = req.body;
      const waveformId = parseInt(req.params.id);
      const waveform = await storage.getWaveformById(waveformId);
      
      if (!waveform) {
        return res.status(404).json({ error: "Waveform not found" });
      }

      const result = await extensionManager.executeExtension(
        extensionName,
        waveform.data as any,
        { enabled: true }
      );

      res.json(result);
    } catch (error) {
      console.error("Analyze waveform error:", error);
      res.status(500).json({ error: "Failed to analyze waveform" });
    }
  });

  // Waveform analysis endpoint
  app.post("/api/analyze-waveform", async (req, res) => {
    try {
      const { waveformData, analysisType } = req.body;
      
      if (!waveformData) {
        return res.status(400).json({ error: "Waveform data is required" });
      }

      const analysis = await analyzeWaveform(waveformData, analysisType || "general");
      res.json({ analysis });
    } catch (error) {
      console.error("Waveform analysis error:", error);
      res.status(500).json({ error: "Failed to analyze waveform" });
    }
  });

  // Side comments endpoints
  app.post("/api/comments", async (req, res) => {
    try {
      const comment = await storage.insertSideComment(req.body);
      res.json(comment);
    } catch (error) {
      console.error("Create comment error:", error);
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  app.get("/api/comments/:messageId", async (req, res) => {
    try {
      const comments = await storage.getSideCommentsByMessageId(parseInt(req.params.messageId));
      res.json(comments);
    } catch (error) {
      console.error("Get comments error:", error);
      res.status(500).json({ error: "Failed to get comments" });
    }
  });

  // Planning items endpoints
  app.post("/api/planning", async (req, res) => {
    try {
      const item = await storage.insertPlanningItem(req.body);
      res.json(item);
    } catch (error) {
      console.error("Create planning item error:", error);
      res.status(500).json({ error: "Failed to create planning item" });
    }
  });

  app.get("/api/planning", async (req, res) => {
    try {
      const items = await storage.getPlanningItems();
      res.json(items);
    } catch (error) {
      console.error("Get planning items error:", error);
      res.status(500).json({ error: "Failed to get planning items" });
    }
  });

  app.patch("/api/planning/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const item = await storage.updatePlanningItemStatus(parseInt(req.params.id), status);
      if (!item) {
        return res.status(404).json({ error: "Planning item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Update planning item error:", error);
      res.status(500).json({ error: "Failed to update planning item" });
    }
  });

  app.delete("/api/planning/:id", async (req, res) => {
    try {
      const deleted = await storage.deletePlanningItem(parseInt(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: "Planning item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete planning item error:", error);
      res.status(500).json({ error: "Failed to delete planning item" });
    }
  });

  // Planning suggestions endpoint
  app.post("/api/planning-suggestions", async (req, res) => {
    try {
      const { currentState, goals } = req.body;
      
      const suggestions = await generatePlanningSuggestions(
        currentState || "neutral",
        goals || []
      );
      res.json({ suggestions });
    } catch (error) {
      console.error("Planning suggestions error:", error);
      res.status(500).json({ error: "Failed to generate suggestions" });
    }
  });

  // Goals endpoints
  app.post("/api/goals", async (req, res) => {
    try {
      const goal = await storage.insertGoal(req.body);
      res.json(goal);
    } catch (error) {
      console.error("Create goal error:", error);
      res.status(500).json({ error: "Failed to create goal" });
    }
  });

  app.get("/api/goals/latest", async (req, res) => {
    try {
      const goal = await storage.getLatestGoal();
      res.json(goal);
    } catch (error) {
      console.error("Get goal error:", error);
      res.status(500).json({ error: "Failed to get goal" });
    }
  });

  app.put("/api/goals/:id", async (req, res) => {
    try {
      const goal = await storage.updateGoal(parseInt(req.params.id), req.body);
      if (!goal) {
        return res.status(404).json({ error: "Goal not found" });
      }
      res.json(goal);
    } catch (error) {
      console.error("Update goal error:", error);
      res.status(500).json({ error: "Failed to update goal" });
    }
  });

  // Metrics endpoints
  app.post("/api/metrics", async (req, res) => {
    try {
      const metric = await storage.insertMetric(req.body);
      res.json(metric);
    } catch (error) {
      console.error("Create metric error:", error);
      res.status(500).json({ error: "Failed to create metric" });
    }
  });

  app.get("/api/metrics", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const metrics = await storage.getRecentMetrics(limit);
      res.json(metrics);
    } catch (error) {
      console.error("Get metrics error:", error);
      res.status(500).json({ error: "Failed to get metrics" });
    }
  });

  app.get("/api/metrics/:type", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const metrics = await storage.getMetricsByType(req.params.type, limit);
      res.json(metrics);
    } catch (error) {
      console.error("Get metrics by type error:", error);
      res.status(500).json({ error: "Failed to get metrics" });
    }
  });

  // Settings endpoints
  app.get("/api/settings", async (req, res) => {
    try {
      let settings = await storage.getSettings();
      if (!settings) {
        // Create default settings if none exist
        settings = await storage.insertSettings({
          aiModel: "advanced",
          samplingRate: "real-time",
          autoSync: true,
          privateMode: false
        });
      }
      res.json(settings);
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ error: "Failed to get settings" });
    }
  });

  app.put("/api/settings", async (req, res) => {
    try {
      const settings = await storage.updateSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Update settings error:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Extensions endpoints
  app.get("/api/extensions", async (req, res) => {
    try {
      // Return the available extensions from extension manager
      const availableExtensions = extensionManager.listExtensions();
      const extensions = availableExtensions.map((ext, index) => ({
        id: index + 1,
        name: ext.name,
        description: ext.description,
        type: ext.type,
        installed: true,
        config: null,
        createdAt: new Date()
      }));
      res.json(extensions);
    } catch (error) {
      console.error("Get extensions error:", error);
      res.status(500).json({ error: "Failed to get extensions" });
    }
  });

  app.patch("/api/extensions/:id/toggle", async (req, res) => {
    try {
      const { installed } = req.body;
      const extension = await storage.toggleExtension(parseInt(req.params.id), installed);
      if (!extension) {
        return res.status(404).json({ error: "Extension not found" });
      }
      res.json(extension);
    } catch (error) {
      console.error("Toggle extension error:", error);
      res.status(500).json({ error: "Failed to toggle extension" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
