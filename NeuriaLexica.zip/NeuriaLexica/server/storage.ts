import type { 
  InsertWaveform, SelectWaveform,
  InsertChatMessage, SelectChatMessage,
  InsertSideComment, SelectSideComment,
  InsertPlanningItem, SelectPlanningItem,
  InsertGoal, SelectGoal,
  InsertMetric, SelectMetric,
  InsertSettings, SelectSettings,
  InsertExtension, SelectExtension
} from "@shared/schema";

export interface IStorage {
  // Waveform operations
  insertWaveform(data: InsertWaveform): Promise<SelectWaveform>;
  getWaveforms(): Promise<SelectWaveform[]>;
  getWaveformById(id: number): Promise<SelectWaveform | null>;
  updateWaveform(id: number, data: Partial<InsertWaveform>): Promise<SelectWaveform | null>;
  deleteWaveform(id: number): Promise<boolean>;

  // Chat message operations
  insertChatMessage(data: InsertChatMessage): Promise<SelectChatMessage>;
  getChatMessages(limit?: number): Promise<SelectChatMessage[]>;
  clearChatHistory(): Promise<boolean>;

  // Side comment operations
  insertSideComment(data: InsertSideComment): Promise<SelectSideComment>;
  getSideCommentsByMessageId(messageId: number): Promise<SelectSideComment[]>;

  // Planning item operations
  insertPlanningItem(data: InsertPlanningItem): Promise<SelectPlanningItem>;
  getPlanningItems(): Promise<SelectPlanningItem[]>;
  updatePlanningItemStatus(id: number, status: string): Promise<SelectPlanningItem | null>;
  deletePlanningItem(id: number): Promise<boolean>;

  // Goal operations
  insertGoal(data: InsertGoal): Promise<SelectGoal>;
  getLatestGoal(): Promise<SelectGoal | null>;
  updateGoal(id: number, data: Partial<InsertGoal>): Promise<SelectGoal | null>;

  // Metric operations
  insertMetric(data: InsertMetric): Promise<SelectMetric>;
  getRecentMetrics(limit?: number): Promise<SelectMetric[]>;
  getMetricsByType(metric: string, limit?: number): Promise<SelectMetric[]>;

  // Settings operations
  insertSettings(data: InsertSettings): Promise<SelectSettings>;
  getSettings(): Promise<SelectSettings | null>;
  updateSettings(data: Partial<InsertSettings>): Promise<SelectSettings | null>;

  // Extension operations
  insertExtension(data: InsertExtension): Promise<SelectExtension>;
  getExtensions(): Promise<SelectExtension[]>;
  toggleExtension(id: number, installed: boolean): Promise<SelectExtension | null>;
}

class MemStorage implements IStorage {
  private waveforms: SelectWaveform[] = [];
  private chatMessages: SelectChatMessage[] = [];
  private sideComments: SelectSideComment[] = [];
  private planningItems: SelectPlanningItem[] = [];
  private goals: SelectGoal[] = [];
  private metrics: SelectMetric[] = [];
  private settings: SelectSettings | null = null;
  private extensions: SelectExtension[] = [];

  private nextId = {
    waveform: 1,
    chatMessage: 1,
    sideComment: 1,
    planningItem: 1,
    goal: 1,
    metric: 1,
    settings: 1,
    extension: 1
  };

  constructor() {
    // Initialize with default extensions
    this.extensions = [
      {
        id: 1,
        name: "Fourier Transform",
        description: "Frequency domain analysis",
        type: "analysis",
        config: null,
        installed: true,
        createdAt: new Date()
      },
      {
        id: 2,
        name: "Pattern Recognition",
        description: "ML-based pattern detection",
        type: "analysis",
        config: null,
        installed: true,
        createdAt: new Date()
      },
      {
        id: 3,
        name: "Biometric Sync",
        description: "Heart rate variability mapping",
        type: "transform",
        config: null,
        installed: true,
        createdAt: new Date()
      },
      {
        id: 4,
        name: "Chaos Theory",
        description: "Nonlinear dynamics analysis",
        type: "analysis",
        config: null,
        installed: false,
        createdAt: new Date()
      },
      {
        id: 5,
        name: "Quantum States",
        description: "Superposition modeling",
        type: "transform",
        config: null,
        installed: false,
        createdAt: new Date()
      }
    ];
    this.nextId.extension = 6;
  }

  // Waveform operations
  async insertWaveform(data: InsertWaveform): Promise<SelectWaveform> {
    const waveform: SelectWaveform = {
      id: this.nextId.waveform++,
      name: data.name,
      type: data.type,
      frequency: data.frequency,
      amplitude: data.amplitude,
      phase: data.phase,
      code: data.code || null,
      basePattern: data.basePattern || null,
      varianceLayer: data.varianceLayer || null,
      temporalResolution: data.temporalResolution || null,
      data: data.data || null,
      createdAt: new Date()
    };
    this.waveforms.push(waveform);
    return waveform;
  }

  async getWaveforms(): Promise<SelectWaveform[]> {
    return [...this.waveforms];
  }

  async getWaveformById(id: number): Promise<SelectWaveform | null> {
    return this.waveforms.find(w => w.id === id) || null;
  }

  async updateWaveform(id: number, data: Partial<InsertWaveform>): Promise<SelectWaveform | null> {
    const index = this.waveforms.findIndex(w => w.id === id);
    if (index === -1) return null;
    this.waveforms[index] = { ...this.waveforms[index], ...data };
    return this.waveforms[index];
  }

  async deleteWaveform(id: number): Promise<boolean> {
    const index = this.waveforms.findIndex(w => w.id === id);
    if (index === -1) return false;
    this.waveforms.splice(index, 1);
    return true;
  }

  // Chat message operations
  async insertChatMessage(data: InsertChatMessage): Promise<SelectChatMessage> {
    const message: SelectChatMessage = {
      id: this.nextId.chatMessage++,
      role: data.role,
      content: data.content,
      planningContext: data.planningContext || null,
      timestamp: new Date()
    };
    this.chatMessages.push(message);
    return message;
  }

  async getChatMessages(limit: number = 100): Promise<SelectChatMessage[]> {
    return this.chatMessages.slice(-limit);
  }

  async clearChatHistory(): Promise<boolean> {
    this.chatMessages = [];
    this.sideComments = [];
    return true;
  }

  // Side comment operations
  async insertSideComment(data: InsertSideComment): Promise<SelectSideComment> {
    const comment: SelectSideComment = {
      id: this.nextId.sideComment++,
      messageId: data.messageId || null,
      content: data.content,
      tag: data.tag,
      createdAt: new Date()
    };
    this.sideComments.push(comment);
    return comment;
  }

  async getSideCommentsByMessageId(messageId: number): Promise<SelectSideComment[]> {
    return this.sideComments.filter(c => c.messageId === messageId);
  }

  // Planning item operations
  async insertPlanningItem(data: InsertPlanningItem): Promise<SelectPlanningItem> {
    const item: SelectPlanningItem = {
      ...data,
      id: this.nextId.planningItem++,
      createdAt: new Date(),
      completedAt: null
    };
    this.planningItems.push(item);
    return item;
  }

  async getPlanningItems(): Promise<SelectPlanningItem[]> {
    return [...this.planningItems];
  }

  async updatePlanningItemStatus(id: number, status: string): Promise<SelectPlanningItem | null> {
    const index = this.planningItems.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.planningItems[index].status = status;
    if (status === 'completed') {
      this.planningItems[index].completedAt = new Date();
    }
    return this.planningItems[index];
  }

  async deletePlanningItem(id: number): Promise<boolean> {
    const index = this.planningItems.findIndex(p => p.id === id);
    if (index === -1) return false;
    this.planningItems.splice(index, 1);
    return true;
  }

  // Goal operations
  async insertGoal(data: InsertGoal): Promise<SelectGoal> {
    const goal: SelectGoal = {
      ...data,
      id: this.nextId.goal++,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.goals.push(goal);
    return goal;
  }

  async getLatestGoal(): Promise<SelectGoal | null> {
    return this.goals[this.goals.length - 1] || null;
  }

  async updateGoal(id: number, data: Partial<InsertGoal>): Promise<SelectGoal | null> {
    const index = this.goals.findIndex(g => g.id === id);
    if (index === -1) return null;
    this.goals[index] = { 
      ...this.goals[index], 
      ...data,
      updatedAt: new Date()
    };
    return this.goals[index];
  }

  // Metric operations
  async insertMetric(data: InsertMetric): Promise<SelectMetric> {
    const metric: SelectMetric = {
      id: this.nextId.metric++,
      metric: data.metric,
      value: data.value,
      change: data.change || null,
      status: data.status,
      timestamp: new Date()
    };
    this.metrics.push(metric);
    return metric;
  }

  async getRecentMetrics(limit: number = 10): Promise<SelectMetric[]> {
    return this.metrics.slice(-limit);
  }

  async getMetricsByType(metric: string, limit: number = 10): Promise<SelectMetric[]> {
    return this.metrics
      .filter(m => m.metric === metric)
      .slice(-limit);
  }

  // Settings operations
  async insertSettings(data: InsertSettings): Promise<SelectSettings> {
    const settings: SelectSettings = {
      id: this.nextId.settings++,
      aiModel: data.aiModel,
      samplingRate: data.samplingRate,
      autoSync: data.autoSync !== undefined ? data.autoSync : true,
      privateMode: data.privateMode !== undefined ? data.privateMode : false,
      updatedAt: new Date()
    };
    this.settings = settings;
    return settings;
  }

  async getSettings(): Promise<SelectSettings | null> {
    return this.settings;
  }

  async updateSettings(data: Partial<InsertSettings>): Promise<SelectSettings | null> {
    if (!this.settings) {
      // Create default settings if none exist
      this.settings = {
        id: this.nextId.settings++,
        aiModel: 'advanced',
        samplingRate: 'real-time',
        autoSync: true,
        privateMode: false,
        updatedAt: new Date(),
        ...data
      };
    } else {
      this.settings = {
        ...this.settings,
        ...data,
        updatedAt: new Date()
      };
    }
    return this.settings;
  }

  // Extension operations
  async insertExtension(data: InsertExtension): Promise<SelectExtension> {
    const extension: SelectExtension = {
      id: this.nextId.extension++,
      name: data.name,
      description: data.description,
      type: data.type,
      config: data.config || null,
      installed: data.installed !== undefined ? data.installed : false,
      createdAt: new Date()
    };
    this.extensions.push(extension);
    return extension;
  }

  async getExtensions(): Promise<SelectExtension[]> {
    return [...this.extensions];
  }

  async toggleExtension(id: number, installed: boolean): Promise<SelectExtension | null> {
    const index = this.extensions.findIndex(e => e.id === id);
    if (index === -1) return null;
    this.extensions[index].installed = installed;
    return this.extensions[index];
  }
}

export const storage = new MemStorage();