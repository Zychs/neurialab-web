import { GoogleGenAI } from "@google/genai";

// This is using Replit's AI Integrations service, which provides Gemini-compatible API access without requiring your own Gemini API key.
const ai = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY || "",
  httpOptions: {
    apiVersion: "",
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
  },
});

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

// Generate AI response for mental health analysis
export async function generateChatResponse(
  messages: ChatMessage[],
  planningContext?: string
): Promise<string> {
  try {
    // Build conversation history
    const conversation = messages.map(msg => 
      `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`
    ).join("\n\n");

    // Create contextual prompt for mental health analysis
    const systemPrompt = `You are an AI assistant specializing in mental health pattern analysis and waveform interpretation. 
    You help users understand their mental states through the lens of waveforms - patterns that represent cognitive and emotional fluctuations.
    
    ${planningContext ? `Current planning context: ${planningContext}\n` : ""}
    
    Previous conversation:
    ${conversation}
    
    Provide thoughtful, analytical responses that help users understand patterns in their mental states. 
    Use metaphors related to waveforms, frequencies, and patterns where appropriate.
    Be supportive but analytical, focusing on pattern recognition and variance analysis.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: systemPrompt,
    });

    return response.text || "I'm having trouble processing that. Could you rephrase your question?";
  } catch (error) {
    console.error("AI generation error:", error);
    return "I'm experiencing some interference in my analysis. Please try again.";
  }
}

// Analyze waveform patterns
export async function analyzeWaveform(
  waveformData: any,
  analysisType: string
): Promise<string> {
  try {
    const prompt = `Analyze this mental state waveform data: ${JSON.stringify(waveformData)}.
    Analysis type: ${analysisType}.
    Provide insights about patterns, variance, stability, and potential correlations.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Unable to analyze waveform at this time.";
  } catch (error) {
    console.error("Waveform analysis error:", error);
    return "Waveform analysis failed. Please check your data.";
  }
}

// Generate planning suggestions based on mental state
export async function generatePlanningSuggestions(
  currentState: string,
  goals: string[]
): Promise<string[]> {
  try {
    const prompt = `Based on the current mental state: "${currentState}" and goals: ${goals.join(", ")},
    suggest 3-5 specific planning objectives that would help achieve mental stability and pattern optimization.
    Return as a JSON array of strings.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const suggestions = JSON.parse(response.text || "[]");
    return Array.isArray(suggestions) ? suggestions : [];
  } catch (error) {
    console.error("Planning generation error:", error);
    return ["Focus on establishing baseline patterns", "Identify key variance triggers"];
  }
}