// Waveform generation and analysis utilities

export interface WaveformPoint {
  x: number;
  y: number;
  timestamp?: number;
}

export interface WaveformData {
  points: WaveformPoint[];
  frequency: number;
  amplitude: number;
  phase: number;
  type: string;
}

// Generate waveform based on type and parameters
export function generateWaveform(
  type: string,
  frequency: number,
  amplitude: number,
  phase: number,
  samples: number = 100
): WaveformPoint[] {
  const points: WaveformPoint[] = [];
  const phaseRad = (phase * Math.PI) / 180;

  for (let i = 0; i < samples; i++) {
    const x = i;
    const t = (2 * Math.PI * frequency * i) / samples + phaseRad;
    let y = 0;

    switch (type) {
      case "sine":
        y = amplitude * Math.sin(t);
        break;
      
      case "square":
        y = amplitude * Math.sign(Math.sin(t));
        break;
      
      case "triangle":
        const period = samples / frequency;
        const localT = i % period;
        const halfPeriod = period / 2;
        if (localT < halfPeriod) {
          y = amplitude * (2 * localT / halfPeriod - 1);
        } else {
          y = amplitude * (3 - 2 * localT / halfPeriod);
        }
        break;
      
      case "sawtooth":
        const sawPeriod = samples / frequency;
        const sawLocalT = i % sawPeriod;
        y = amplitude * (2 * sawLocalT / sawPeriod - 1);
        break;
      
      default:
        y = amplitude * Math.sin(t);
    }

    points.push({ x, y });
  }

  return points;
}

// Apply mental state pattern to waveform
export function applyMentalStatePattern(
  basePoints: WaveformPoint[],
  pattern: string,
  variance: string
): WaveformPoint[] {
  const modifiedPoints: WaveformPoint[] = [];
  
  // Pattern modulation factors
  const patternFactors: Record<string, number> = {
    focused: 1.0,
    creative: 1.2,
    relaxed: 0.7,
    energized: 1.5
  };
  
  // Variance factors
  const varianceFactors: Record<string, number> = {
    stable: 0.05,
    moderate: 0.15,
    dynamic: 0.3,
    chaotic: 0.5
  };
  
  const patternMod = patternFactors[pattern] || 1.0;
  const varianceMod = varianceFactors[variance] || 0.15;
  
  for (const point of basePoints) {
    // Add variance noise
    const noise = (Math.random() - 0.5) * varianceMod;
    
    // Apply pattern modulation
    const modifiedY = point.y * patternMod + noise * point.y;
    
    modifiedPoints.push({
      x: point.x,
      y: modifiedY,
      timestamp: Date.now() + point.x * 1000 // Simulate temporal data
    });
  }
  
  return modifiedPoints;
}

// Calculate waveform metrics
export function calculateWaveformMetrics(points: WaveformPoint[]): {
  stability: number;
  consistency: number;
  recovery: number;
  adaptation: number;
} {
  if (points.length < 2) {
    return { stability: 0, consistency: 0, recovery: 0, adaptation: 0 };
  }

  // Calculate stability (inverse of variance)
  const mean = points.reduce((sum, p) => sum + p.y, 0) / points.length;
  const variance = points.reduce((sum, p) => sum + Math.pow(p.y - mean, 2), 0) / points.length;
  const stability = Math.max(0, Math.min(100, 100 - variance));

  // Calculate consistency (autocorrelation)
  let consistency = 0;
  for (let i = 1; i < points.length; i++) {
    const diff = Math.abs(points[i].y - points[i - 1].y);
    consistency += 1 / (1 + diff);
  }
  consistency = (consistency / (points.length - 1)) * 100;

  // Calculate recovery (how quickly returns to baseline)
  let recovery = 0;
  let crossings = 0;
  for (let i = 1; i < points.length; i++) {
    if ((points[i].y > 0 && points[i - 1].y <= 0) || 
        (points[i].y <= 0 && points[i - 1].y > 0)) {
      crossings++;
    }
  }
  recovery = Math.min(100, (crossings / points.length) * 200);

  // Calculate adaptation (response to changes)
  let adaptation = 0;
  const segments = 5;
  const segmentSize = Math.floor(points.length / segments);
  for (let s = 0; s < segments - 1; s++) {
    const segStart = s * segmentSize;
    const segEnd = (s + 1) * segmentSize;
    const nextSegStart = segEnd;
    const nextSegEnd = Math.min((s + 2) * segmentSize, points.length);
    
    const segMean = points.slice(segStart, segEnd).reduce((sum, p) => sum + p.y, 0) / segmentSize;
    const nextSegMean = points.slice(nextSegStart, nextSegEnd).reduce((sum, p) => sum + p.y, 0) / (nextSegEnd - nextSegStart);
    
    adaptation += Math.abs(nextSegMean - segMean);
  }
  adaptation = Math.min(100, adaptation * 10);

  return {
    stability: Math.round(stability),
    consistency: Math.round(consistency),
    recovery: Math.round(recovery),
    adaptation: Math.round(adaptation)
  };
}

// Analyze frequency spectrum using FFT approximation
export function analyzeFrequencySpectrum(points: WaveformPoint[]): {
  dominantFrequency: number;
  harmonics: number[];
  spectralEnergy: number;
} {
  // Simplified FFT for demo purposes
  const n = points.length;
  const frequencies: number[] = [];
  
  // Calculate frequency components
  for (let k = 0; k < n / 2; k++) {
    let real = 0;
    let imag = 0;
    
    for (let i = 0; i < n; i++) {
      const angle = -2 * Math.PI * k * i / n;
      real += points[i].y * Math.cos(angle);
      imag += points[i].y * Math.sin(angle);
    }
    
    const magnitude = Math.sqrt(real * real + imag * imag) / n;
    frequencies.push(magnitude);
  }
  
  // Find dominant frequency
  let maxMag = 0;
  let dominantIndex = 0;
  for (let i = 1; i < frequencies.length; i++) {
    if (frequencies[i] > maxMag) {
      maxMag = frequencies[i];
      dominantIndex = i;
    }
  }
  
  // Find harmonics (peaks at multiples of dominant)
  const harmonics: number[] = [];
  for (let h = 2; h <= 5; h++) {
    const harmonicIndex = dominantIndex * h;
    if (harmonicIndex < frequencies.length && frequencies[harmonicIndex] > maxMag * 0.1) {
      harmonics.push(h);
    }
  }
  
  // Calculate spectral energy
  const spectralEnergy = frequencies.reduce((sum, f) => sum + f * f, 0);
  
  return {
    dominantFrequency: dominantIndex,
    harmonics,
    spectralEnergy: Math.round(spectralEnergy * 100)
  };
}

// Combine multiple waveforms
export function combineWaveforms(
  waveforms: WaveformData[],
  weights: number[] = []
): WaveformPoint[] {
  if (waveforms.length === 0) return [];
  
  const finalWeights = weights.length === waveforms.length 
    ? weights 
    : new Array(waveforms.length).fill(1 / waveforms.length);
  
  const maxSamples = Math.max(...waveforms.map(w => w.points.length));
  const combined: WaveformPoint[] = [];
  
  for (let i = 0; i < maxSamples; i++) {
    let x = i;
    let y = 0;
    
    for (let w = 0; w < waveforms.length; w++) {
      const waveform = waveforms[w];
      if (i < waveform.points.length) {
        y += waveform.points[i].y * finalWeights[w];
      }
    }
    
    combined.push({ x, y });
  }
  
  return combined;
}