// Extensions system for waveform analysis plugins
import { WaveformPoint, analyzeFrequencySpectrum, calculateWaveformMetrics } from "./waveform";

export interface ExtensionResult {
  extensionName: string;
  result: any;
  timestamp: Date;
}

export interface ExtensionConfig {
  enabled: boolean;
  parameters?: Record<string, any>;
}

// Extension execution interface
export interface IExtension {
  name: string;
  description: string;
  type: "analysis" | "transform" | "visualization";
  execute(data: WaveformPoint[], config?: ExtensionConfig): Promise<ExtensionResult>;
}

// Fourier Transform Extension
class FourierTransformExtension implements IExtension {
  name = "Fourier Transform";
  description = "Frequency domain analysis";
  type = "analysis" as const;

  async execute(data: WaveformPoint[], config?: ExtensionConfig): Promise<ExtensionResult> {
    const spectrum = analyzeFrequencySpectrum(data);
    
    return {
      extensionName: this.name,
      result: {
        dominantFrequency: spectrum.dominantFrequency,
        harmonics: spectrum.harmonics,
        spectralEnergy: spectrum.spectralEnergy,
        frequencyBins: this.calculateFrequencyBins(data)
      },
      timestamp: new Date()
    };
  }

  private calculateFrequencyBins(points: WaveformPoint[]): number[] {
    const bins: number[] = new Array(10).fill(0);
    const binSize = points.length / 10;
    
    for (let i = 0; i < points.length; i++) {
      const binIndex = Math.min(9, Math.floor(i / binSize));
      bins[binIndex] += Math.abs(points[i].y);
    }
    
    return bins.map(b => Math.round(b / binSize * 100) / 100);
  }
}

// Pattern Recognition Extension
class PatternRecognitionExtension implements IExtension {
  name = "Pattern Recognition";
  description = "ML-based pattern detection";
  type = "analysis" as const;

  async execute(data: WaveformPoint[], config?: ExtensionConfig): Promise<ExtensionResult> {
    const patterns = this.detectPatterns(data);
    const metrics = calculateWaveformMetrics(data);
    
    return {
      extensionName: this.name,
      result: {
        detectedPatterns: patterns,
        confidence: this.calculateConfidence(patterns),
        metrics: metrics,
        anomalies: this.detectAnomalies(data)
      },
      timestamp: new Date()
    };
  }

  private detectPatterns(points: WaveformPoint[]): string[] {
    const patterns: string[] = [];
    
    // Detect periodic patterns
    let isPeriodic = true;
    const period = Math.floor(points.length / 4);
    for (let i = period; i < points.length; i++) {
      const diff = Math.abs(points[i].y - points[i - period].y);
      if (diff > 0.3 * Math.abs(points[i].y)) {
        isPeriodic = false;
        break;
      }
    }
    if (isPeriodic) patterns.push("periodic");
    
    // Detect trending patterns
    const firstHalf = points.slice(0, points.length / 2);
    const secondHalf = points.slice(points.length / 2);
    const firstMean = firstHalf.reduce((sum, p) => sum + p.y, 0) / firstHalf.length;
    const secondMean = secondHalf.reduce((sum, p) => sum + p.y, 0) / secondHalf.length;
    
    if (secondMean > firstMean * 1.2) patterns.push("ascending");
    else if (secondMean < firstMean * 0.8) patterns.push("descending");
    else patterns.push("stable");
    
    // Detect oscillation
    let crossings = 0;
    for (let i = 1; i < points.length; i++) {
      if ((points[i].y > 0 && points[i - 1].y <= 0) || 
          (points[i].y <= 0 && points[i - 1].y > 0)) {
        crossings++;
      }
    }
    if (crossings > points.length / 10) patterns.push("oscillating");
    
    return patterns;
  }

  private calculateConfidence(patterns: string[]): number {
    // Simple confidence based on pattern count
    return Math.min(100, patterns.length * 25);
  }

  private detectAnomalies(points: WaveformPoint[]): number[] {
    const anomalies: number[] = [];
    const mean = points.reduce((sum, p) => sum + p.y, 0) / points.length;
    const stdDev = Math.sqrt(points.reduce((sum, p) => sum + Math.pow(p.y - mean, 2), 0) / points.length);
    
    for (let i = 0; i < points.length; i++) {
      if (Math.abs(points[i].y - mean) > 2 * stdDev) {
        anomalies.push(i);
      }
    }
    
    return anomalies;
  }
}

// Biometric Sync Extension
class BiometricSyncExtension implements IExtension {
  name = "Biometric Sync";
  description = "Heart rate variability mapping";
  type = "transform" as const;

  async execute(data: WaveformPoint[], config?: ExtensionConfig): Promise<ExtensionResult> {
    const hrv = this.calculateHRV(data);
    const coherence = this.calculateCoherence(data);
    const transformed = this.transformToHRV(data, hrv);
    
    return {
      extensionName: this.name,
      result: {
        hrv: hrv,
        coherence: coherence,
        stressLevel: this.calculateStressLevel(hrv, coherence),
        transformedData: transformed,
        breathingRate: this.estimateBreathingRate(data)
      },
      timestamp: new Date()
    };
  }

  private calculateHRV(points: WaveformPoint[]): number {
    // Simulate HRV calculation from waveform
    let hrv = 0;
    for (let i = 1; i < points.length; i++) {
      hrv += Math.abs(points[i].y - points[i - 1].y);
    }
    return Math.round(hrv / points.length * 100) / 100;
  }

  private calculateCoherence(points: WaveformPoint[]): number {
    // Calculate coherence as regularity of pattern
    let coherence = 0;
    const windowSize = 5;
    
    for (let i = windowSize; i < points.length - windowSize; i++) {
      const localMean = points.slice(i - windowSize, i + windowSize)
        .reduce((sum, p) => sum + p.y, 0) / (windowSize * 2);
      coherence += 1 / (1 + Math.abs(points[i].y - localMean));
    }
    
    return Math.round(coherence / (points.length - windowSize * 2) * 100);
  }

  private calculateStressLevel(hrv: number, coherence: number): string {
    const stressScore = (100 - coherence) + hrv / 2;
    if (stressScore < 30) return "low";
    if (stressScore < 60) return "moderate";
    return "high";
  }

  private transformToHRV(points: WaveformPoint[], hrv: number): WaveformPoint[] {
    return points.map(p => ({
      x: p.x,
      y: p.y * (1 + hrv / 100)
    }));
  }

  private estimateBreathingRate(points: WaveformPoint[]): number {
    // Estimate breathing rate from waveform pattern (breaths per minute)
    let peaks = 0;
    for (let i = 1; i < points.length - 1; i++) {
      if (points[i].y > points[i - 1].y && points[i].y > points[i + 1].y) {
        peaks++;
      }
    }
    // Assuming data represents 1 minute of recording
    return Math.round(peaks * 60 / points.length);
  }
}

// Chaos Theory Extension (not installed by default)
class ChaosTheoryExtension implements IExtension {
  name = "Chaos Theory";
  description = "Nonlinear dynamics analysis";
  type = "analysis" as const;

  async execute(data: WaveformPoint[], config?: ExtensionConfig): Promise<ExtensionResult> {
    const lyapunov = this.calculateLyapunovExponent(data);
    const fractalDim = this.calculateFractalDimension(data);
    const entropy = this.calculateEntropy(data);
    
    return {
      extensionName: this.name,
      result: {
        lyapunovExponent: lyapunov,
        fractalDimension: fractalDim,
        entropy: entropy,
        chaosLevel: this.determineChaosLevel(lyapunov, fractalDim, entropy),
        attractors: this.findAttractors(data)
      },
      timestamp: new Date()
    };
  }

  private calculateLyapunovExponent(points: WaveformPoint[]): number {
    // Simplified Lyapunov exponent calculation
    let sum = 0;
    for (let i = 1; i < points.length; i++) {
      const diff = Math.abs(points[i].y - points[i - 1].y);
      if (diff > 0) {
        sum += Math.log(diff);
      }
    }
    return sum / points.length;
  }

  private calculateFractalDimension(points: WaveformPoint[]): number {
    // Box-counting dimension approximation
    const boxes = new Set<string>();
    const scale = 10;
    
    for (const point of points) {
      const boxX = Math.floor(point.x / scale);
      const boxY = Math.floor(point.y / scale);
      boxes.add(`${boxX},${boxY}`);
    }
    
    return Math.log(boxes.size) / Math.log(scale);
  }

  private calculateEntropy(points: WaveformPoint[]): number {
    // Shannon entropy calculation
    const bins: Record<number, number> = {};
    const binSize = 0.1;
    
    for (const point of points) {
      const bin = Math.floor(point.y / binSize);
      bins[bin] = (bins[bin] || 0) + 1;
    }
    
    let entropy = 0;
    const total = points.length;
    
    for (const count of Object.values(bins)) {
      const p = count / total;
      if (p > 0) {
        entropy -= p * Math.log2(p);
      }
    }
    
    return entropy;
  }

  private determineChaosLevel(lyapunov: number, fractal: number, entropy: number): string {
    const score = Math.abs(lyapunov) + fractal + entropy;
    if (score < 5) return "ordered";
    if (score < 10) return "edge-of-chaos";
    return "chaotic";
  }

  private findAttractors(points: WaveformPoint[]): number[] {
    // Find stable points (attractors)
    const attractors: number[] = [];
    const threshold = 0.1;
    
    for (let i = 10; i < points.length - 10; i++) {
      const localMean = points.slice(i - 5, i + 5)
        .reduce((sum, p) => sum + p.y, 0) / 10;
      
      if (Math.abs(points[i].y - localMean) < threshold) {
        attractors.push(points[i].y);
      }
    }
    
    // Use Array.from to convert Set to Array for compatibility
    const uniqueAttractors = Array.from(new Set(attractors.map(a => Math.round(a * 10) / 10)));
    return uniqueAttractors;
  }
}

// Extension Manager
export class ExtensionManager {
  private extensions: Map<string, IExtension> = new Map();

  constructor() {
    // Register default extensions
    this.registerExtension(new FourierTransformExtension());
    this.registerExtension(new PatternRecognitionExtension());
    this.registerExtension(new BiometricSyncExtension());
    this.registerExtension(new ChaosTheoryExtension());
  }

  registerExtension(extension: IExtension): void {
    this.extensions.set(extension.name, extension);
  }

  async executeExtension(
    extensionName: string,
    data: WaveformPoint[],
    config?: ExtensionConfig
  ): Promise<ExtensionResult | null> {
    const extension = this.extensions.get(extensionName);
    if (!extension) {
      console.error(`Extension ${extensionName} not found`);
      return null;
    }

    try {
      return await extension.execute(data, config);
    } catch (error) {
      console.error(`Error executing extension ${extensionName}:`, error);
      return null;
    }
  }

  getExtension(name: string): IExtension | undefined {
    return this.extensions.get(name);
  }

  listExtensions(): IExtension[] {
    return Array.from(this.extensions.values());
  }
}

// Export singleton instance
export const extensionManager = new ExtensionManager();